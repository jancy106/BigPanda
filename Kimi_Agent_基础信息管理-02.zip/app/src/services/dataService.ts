import type {
  User, Department, AccountSubject, Project, AnnualBudget, MonthlyBudget,
  PaymentPlan, ActualExpense, BudgetExecution, Alert, TrendData,
  DashboardData, DepartmentStat, ProjectExpenseAnalysis, SystemConfig
} from '@/types';

// 存储键
const STORAGE_KEYS = {
  users: 'biopharma_users',
  departments: 'biopharma_departments',
  subjects: 'biopharma_subjects',
  projects: 'biopharma_projects',
  annualBudgets: 'biopharma_annual_budgets',
  monthlyBudgets: 'biopharma_monthly_budgets',
  paymentPlans: 'biopharma_payment_plans',
  actualExpenses: 'biopharma_actual_expenses',
  alerts: 'biopharma_alerts',
  insights: 'biopharma_insights',
  config: 'biopharma_config',
  currentUser: 'biopharma_current_user'
};

// 验证数据是否有效
function isValidData(data: any, type: string): boolean {
  if (!data || !Array.isArray(data)) return false;
  if (data.length === 0) return true; // 空数组是有效的
  
  switch (type) {
    case 'departments':
      return data.every(d => d && d.id && d.name && d.code);
    case 'subjects':
      return data.every(s => s && s.id && s.name && s.code);
    case 'projects':
      return data.every(p => p && p.id && p.name && p.code);
    case 'users':
      return data.every(u => u && u.id && u.name && u.email && u.role);
    default:
      return true;
  }
}

// 初始化默认数据
export function initializeDefaultData() {
  try {
    // 检查并清除无效数据
    const depts = localStorage.getItem(STORAGE_KEYS.departments);
    if (depts && !isValidData(JSON.parse(depts), 'departments')) {
      localStorage.removeItem(STORAGE_KEYS.departments);
    }
    const subs = localStorage.getItem(STORAGE_KEYS.subjects);
    if (subs && !isValidData(JSON.parse(subs), 'subjects')) {
      localStorage.removeItem(STORAGE_KEYS.subjects);
    }
    const projs = localStorage.getItem(STORAGE_KEYS.projects);
    if (projs && !isValidData(JSON.parse(projs), 'projects')) {
      localStorage.removeItem(STORAGE_KEYS.projects);
    }
    const usrs = localStorage.getItem(STORAGE_KEYS.users);
    if (usrs && !isValidData(JSON.parse(usrs), 'users')) {
      localStorage.removeItem(STORAGE_KEYS.users);
    }

    // 部门数据 - 来自基础数据表
    const defaultDepartments: Department[] = [
      { id: 'dept_1', name: '研发中心', code: 'DEP-001', managerId: 'user_3', description: '负责人：乔怀耀' },
      { id: 'dept_2', name: '临床运营部', code: 'DEP-002', managerId: 'user_4', description: '负责人：孙涛' },
      { id: 'dept_3', name: '临床医学部', code: 'DEP-003', managerId: 'user_5', description: '负责人：李长岭' },
      { id: 'dept_4', name: '临床协调部', code: 'DEP-004', managerId: 'user_4', description: '负责人：孙涛' },
      { id: 'dept_5', name: '药政事务部', code: 'DEP-005', managerId: 'user_6', description: '负责人：蒋丽雯' },
      { id: 'dept_6', name: '项目管理部', code: 'DEP-006', managerId: 'user_7', description: '负责人：张露' },
      { id: 'dept_7', name: '品牌与医学市场部', code: 'DEP-007', managerId: 'user_8', description: '负责人：袁培' },
      { id: 'dept_8', name: '投资发展部', code: 'DEP-008', managerId: 'user_9', description: '负责人：端木传云' },
      { id: 'dept_9', name: '综合管理部', code: 'DEP-009', managerId: 'user_10', description: '负责人：陶乐珺' }
    ];

    // 预算科目数据 - 来自基础数据表
    const defaultSubjects: AccountSubject[] = [
      // 人员薪酬类
      { id: 'sub_1', code: 'FID-001', name: '研发人员薪酬', category: 'expense', description: '' },
      { id: 'sub_2', code: 'FID-002', name: '临床人员薪酬', category: 'expense', description: '' },
      { id: 'sub_3', code: 'FID-003', name: '管理人员薪酬', category: 'expense', description: '' },
      { id: 'sub_4', code: 'FID-004', name: '外聘专家咨询费', category: 'expense', description: '' },
      { id: 'sub_5', code: 'FID-005', name: '劳务外包费', category: 'expense', description: '' },
      
      // 临床试验费类
      { id: 'sub_6', code: 'FID-101', name: 'CRO服务费', category: 'expense', description: '合同研究组织服务费' },
      { id: 'sub_7', code: 'FID-102', name: '研究者费', category: 'expense', description: '研究者观察、评估、随访费' },
      { id: 'sub_8', code: 'FID-103', name: '临床机构费', category: 'expense', description: '机构启动费、管理费、科室使用费' },
      { id: 'sub_9', code: 'FID-104', name: '受试者补偿费', category: 'expense', description: '受试者交通费、误工费、营养费、采血补助等' },
      { id: 'sub_10', code: 'FID-105', name: '临床试验材料费', category: 'expense', description: '临床试验用药品、试剂、耗材、冷链包装材料等' },
      { id: 'sub_11', code: 'FID-106', name: '医疗服务费', category: 'expense', description: '医疗机构服务费用' },
      { id: 'sub_12', code: 'FID-107', name: '中心检测检验费', category: 'expense', description: '实验室检测、影像学检查费用、临床样本药代、生化、免疫检测用' },
      { id: 'sub_13', code: 'FID-108', name: '数据管理与统计费', category: 'expense', description: '数据录入、整理、统计分析费用' },
      { id: 'sub_14', code: 'FID-109', name: '伦理费', category: 'expense', description: '伦理委员会审查费用等' },
      { id: 'sub_15', code: 'FID-110', name: '临床试验保险费', category: 'expense', description: '受试者保险、临床试验责任险' },
      { id: 'sub_16', code: 'FID-111', name: '稽查/核查费', category: 'expense', description: '第三方稽查、内部稽查费' },
      { id: 'sub_17', code: 'FID-112', name: '临床软件开发费', category: 'expense', description: '临床试验相关的软件开发费' },
      { id: 'sub_18', code: 'FID-113', name: '研究者培训费', category: 'expense', description: '研究者会、启动会培训' },
      { id: 'sub_19', code: 'FID-114', name: '临床研究其他费用', category: 'expense', description: '未纳入上述科目的临床研究费' },
      
      // 研发费类
      { id: 'sub_20', code: 'FID-201', name: '材料费', category: 'expense', description: '原料药、辅料、包材、对照品、培养基等，实验耗材费用，冷链包装材料等' },
      { id: 'sub_21', code: 'FID-202', name: '检测分析费', category: 'expense', description: '实验室或检测机构的检测、分析费用' },
      { id: 'sub_22', code: 'FID-203', name: '方法验证/确认费', category: 'expense', description: '分析方法验证、转移、确认' },
      { id: 'sub_23', code: 'FID-204', name: '稳定性研究费', category: 'expense', description: '长期、加速、影响因素、留样观察' },
      { id: 'sub_24', code: 'FID-205', name: '放行检测费', category: 'expense', description: '临床前/临床样品出厂放行检验' },
      { id: 'sub_25', code: 'FID-206', name: '工艺/制剂/中试开发费', category: 'expense', description: '处方工艺开发、剂型开发、中试放大、工艺优化' },
      { id: 'sub_26', code: 'FID-207', name: '非临床研究费', category: 'expense', description: '药效、药理、毒理、药代动力学等试验（委托研究费用）' },
      { id: 'sub_27', code: 'FID-208', name: '知识产权费', category: 'expense', description: '专利/著作申请、维持、检索、答复等费用' },
      { id: 'sub_28', code: 'FID-209', name: '研发其他费用', category: 'expense', description: '未纳入上述科目的研发费' },
      
      // 药政事务费类
      { id: 'sub_29', code: 'FID-301', name: '官方行政缴费', category: 'expense', description: 'CDE/NMPA/各地区监管机构申请费、审评费' },
      { id: 'sub_30', code: 'FID-302', name: '注册资料费', category: 'expense', description: '资料编制、整理、翻译、公证、打印' },
      { id: 'sub_31', code: 'FID-303', name: '注册咨询/代理费', category: 'expense', description: '注册咨询、注册代理、发补资料' },
      { id: 'sub_32', code: 'FID-304', name: '沟通会议费', category: 'expense', description: 'Pre-IND、EOP、Pre-NDA、BLA沟通会' },
      
      // 市场费类
      { id: 'sub_33', code: 'FID-401', name: '学术推广费', category: 'operating', description: '学术会议、学术推广等活动' },
      { id: 'sub_34', code: 'FID-402', name: '市场调研费', category: 'operating', description: '市场调研、行业调研' },
      { id: 'sub_35', code: 'FID-403', name: '品牌宣传费', category: 'operating', description: '品牌建设与维护、广告费用等' },
      { id: 'sub_36', code: 'FID-404', name: '咨询服务费', category: 'operating', description: '第三方咨询与服务' },
      
      // 综合管理费类
      { id: 'sub_37', code: 'FID-501', name: '办公费', category: 'operating', description: '纸笔、打印耗材、水；电话、网络；快递、邮寄；系统/账号/云盘/企业邮箱等' },
      { id: 'sub_38', code: 'FID-502', name: '会议费', category: 'operating', description: '' },
      { id: 'sub_39', code: 'FID-503', name: '招聘费', category: 'operating', description: '人员招聘' },
      { id: 'sub_40', code: 'FID-504', name: '租赁与物业费', category: 'operating', description: '办公场所、设备租赁费用' },
      { id: 'sub_41', code: 'FID-505', name: '差旅费', category: 'operating', description: '' },
      { id: 'sub_42', code: 'FID-506', name: '业务招待费', category: 'operating', description: '' },
      { id: 'sub_43', code: 'FID-507', name: '培训费', category: 'operating', description: '' },
      { id: 'sub_44', code: 'FID-508', name: '综合管理其他费用', category: 'operating', description: '' }
    ];

    // 项目数据 - 来自基础数据表
    const defaultProjects: Project[] = [
      { id: 'proj_1', code: 'GS101', name: '度普利尤生物类似药', status: 'ongoing', startDate: '2024-01-01', description: '负责人：乔怀耀' },
      { id: 'proj_2', code: 'GS101-1', name: '度普利尤单抗Ⅰ期临床', status: 'ongoing', startDate: '2024-03-01', description: '负责人：孙涛' },
      { id: 'proj_3', code: 'GS101-3', name: '度普利尤单抗Ⅲ期临床', status: 'ongoing', startDate: '2024-06-01', description: '负责人：孙涛' },
      { id: 'proj_4', code: 'GS102', name: '利生奇珠生物类似药', status: 'ongoing', startDate: '2024-01-01', description: '负责人：乔怀耀' },
      { id: 'proj_5', code: 'GS201', name: '帕博利珠生物类似药', status: 'planning', startDate: '2025-01-01', description: '负责人：乔怀耀' },
      { id: 'proj_6', code: 'GS202', name: '埃万妥生物类似药', status: 'planning', startDate: '2025-06-01', description: '负责人：乔怀耀' },
      { id: 'proj_7', code: 'GS203', name: '德曲妥珠生物类似药', status: 'planning', startDate: '2025-09-01', description: '负责人：乔怀耀' },
      { id: 'proj_8', code: 'GS301', name: '法瑞西生物类似药', status: 'planning', startDate: '2026-01-01', description: '负责人：乔怀耀' },
      { id: 'proj_9', code: 'Others', name: '无固定项目', status: 'ongoing', startDate: '2024-01-01', description: '通用费用' }
    ];

    // 用户数据
    const defaultUsers: User[] = [
      { id: 'user_1', email: 'admin@biopharma.com', name: '系统管理员', role: 'admin' },
      { id: 'user_2', email: 'boss@biopharma.com', name: '总经理', role: 'boss' },
      { id: 'user_3', email: 'qiao@biopharma.com', name: '乔怀耀', role: 'manager', departmentId: 'dept_1' },
      { id: 'user_4', email: 'sun@biopharma.com', name: '孙涛', role: 'manager', departmentId: 'dept_2' },
      { id: 'user_5', email: 'li@biopharma.com', name: '李长岭', role: 'manager', departmentId: 'dept_3' },
      { id: 'user_6', email: 'jiang@biopharma.com', name: '蒋丽雯', role: 'manager', departmentId: 'dept_5' },
      { id: 'user_7', email: 'zhang@biopharma.com', name: '张露', role: 'manager', departmentId: 'dept_6' },
      { id: 'user_8', email: 'yuan@biopharma.com', name: '袁培', role: 'manager', departmentId: 'dept_7' },
      { id: 'user_9', email: 'duanmu@biopharma.com', name: '端木传云', role: 'manager', departmentId: 'dept_8' },
      { id: 'user_10', email: 'tao@biopharma.com', name: '陶乐珺', role: 'manager', departmentId: 'dept_9' }
    ];

    // 系统配置
    const defaultConfig: SystemConfig = {
      companyName: '生物制药有限公司',
      fiscalYear: 2026,
      paymentPlanDeadline: 25,
      currency: 'CNY',
      budgetAlertThreshold: 90
    };

    // 初始化存储
    if (!localStorage.getItem(STORAGE_KEYS.departments)) {
      localStorage.setItem(STORAGE_KEYS.departments, JSON.stringify(defaultDepartments));
    }
    if (!localStorage.getItem(STORAGE_KEYS.subjects)) {
      localStorage.setItem(STORAGE_KEYS.subjects, JSON.stringify(defaultSubjects));
    }
    if (!localStorage.getItem(STORAGE_KEYS.projects)) {
      localStorage.setItem(STORAGE_KEYS.projects, JSON.stringify(defaultProjects));
    }
    if (!localStorage.getItem(STORAGE_KEYS.users)) {
      localStorage.setItem(STORAGE_KEYS.users, JSON.stringify(defaultUsers));
    }
    if (!localStorage.getItem(STORAGE_KEYS.config)) {
      localStorage.setItem(STORAGE_KEYS.config, JSON.stringify(defaultConfig));
    }

    // 生成模拟预算和支出数据
    generateMockData();
  } catch (error) {
    console.error('初始化默认数据失败:', error);
    throw error;
  }
}

// 生成模拟数据
function generateMockData() {
  try {
    const year = 2026;
    const departments = getDepartments();
    const subjects = getSubjects();
    const projects = getProjects();

    // 如果数据已存在，不重新生成
    if (localStorage.getItem(STORAGE_KEYS.annualBudgets)) {
      return;
    }

    // 生成年度预算
    const annualBudgets: AnnualBudget[] = [];
    departments.forEach(dept => {
      subjects.forEach(subject => {
        projects.forEach(project => {
          const baseAmount = Math.random() * 500000 + 100000;
          annualBudgets.push({
            id: `ab_${dept.id}_${subject.id}_${project.id}`,
            year,
            departmentId: dept.id,
            subjectId: subject.id,
            projectId: project.id,
            amount: Math.round(baseAmount),
            createdAt: new Date().toISOString(),
            updatedAt: new Date().toISOString()
          });
        });
      });
    });
    localStorage.setItem(STORAGE_KEYS.annualBudgets, JSON.stringify(annualBudgets));

    // 生成月度预算和实际支出
    const monthlyBudgets: MonthlyBudget[] = [];
    const actualExpenses: ActualExpense[] = [];

    for (let month = 1; month <= 3; month++) {
      departments.forEach(dept => {
        subjects.forEach(subject => {
          projects.forEach(project => {
            const annualBudget = annualBudgets.find(
              ab => ab.departmentId === dept.id && ab.subjectId === subject.id && ab.projectId === project.id
            );
            if (annualBudget) {
              const monthlyAmount = annualBudget.amount / 12 * (0.8 + Math.random() * 0.4);
              monthlyBudgets.push({
                id: `mb_${year}_${month}_${dept.id}_${subject.id}_${project.id}`,
                year,
                month,
                departmentId: dept.id,
                subjectId: subject.id,
                projectId: project.id,
                amount: Math.round(monthlyAmount),
                createdAt: new Date().toISOString(),
                updatedAt: new Date().toISOString()
              });

              // 生成实际支出（与预算有一定差异）
              const actualAmount = monthlyAmount * (0.7 + Math.random() * 0.6);
              if (actualAmount > 0) {
                actualExpenses.push({
                  id: `ae_${year}_${month}_${dept.id}_${subject.id}_${project.id}_${Math.random().toString(36).substr(2, 9)}`,
                  date: `${year}-${String(month).padStart(2, '0')}-${String(Math.floor(Math.random() * 28) + 1).padStart(2, '0')}`,
                  year,
                  month,
                  departmentId: dept.id,
                  subjectId: subject.id,
                  projectId: project.id,
                  amount: Math.round(actualAmount),
                  description: `${subject.name}支出`,
                  vendor: '供应商' + Math.floor(Math.random() * 10),
                  paymentMethod: 'bank',
                  recorderId: 'user_1',
                  recordedAt: new Date().toISOString()
                });
              }
            }
          });
        });
      });
    }

    localStorage.setItem(STORAGE_KEYS.monthlyBudgets, JSON.stringify(monthlyBudgets));
    localStorage.setItem(STORAGE_KEYS.actualExpenses, JSON.stringify(actualExpenses));

    // 生成付款计划
    const paymentPlans: PaymentPlan[] = [];
    departments.forEach(dept => {
      subjects.slice(0, 5).forEach(subject => {
        const planAmount = Math.random() * 100000 + 50000;
        paymentPlans.push({
          id: `pp_${year}_4_${dept.id}_${subject.id}_${Math.random().toString(36).substr(2, 9)}`,
          year,
          month: 4,
          departmentId: dept.id,
          subjectId: subject.id,
          projectId: Math.random() > 0.3 ? projects[Math.floor(Math.random() * projects.length)].id : undefined,
          amount: Math.round(planAmount),
          description: `${subject.name}付款计划`,
          vendor: '供应商' + Math.floor(Math.random() * 10),
          status: Math.random() > 0.5 ? 'submitted' : 'draft',
          submitterId: dept.managerId || 'user_1',
          submittedAt: new Date().toISOString()
        });
      });
    });
    localStorage.setItem(STORAGE_KEYS.paymentPlans, JSON.stringify(paymentPlans));

    // 生成预警
    generateAlerts();
  } catch (error) {
    console.error('生成模拟数据失败:', error);
  }
}

// 生成预警
function generateAlerts() {
  try {
    // 如果预警已存在，不重新生成
    if (localStorage.getItem(STORAGE_KEYS.alerts)) {
      return;
    }
    
    const alerts: Alert[] = [
      {
        id: 'alert_1',
        type: 'overspend',
        level: 'critical',
        title: '研发中心预算超支预警',
        message: '研发中心CRO服务费已超支15%，请立即关注',
        departmentId: 'dept_1',
        createdAt: new Date().toISOString(),
        isRead: false
      },
      {
        id: 'alert_2',
        type: 'deadline',
        level: 'warning',
        title: '4月付款计划提交截止提醒',
        message: '距离4月付款计划提交截止还有3天',
        createdAt: new Date().toISOString(),
        isRead: false
      },
      {
        id: 'alert_3',
        type: 'variance',
        level: 'info',
        title: '临床运营部预算执行偏差',
        message: '研究者费实际支出低于预算20%',
        departmentId: 'dept_2',
        createdAt: new Date().toISOString(),
        isRead: true,
        readAt: new Date().toISOString()
      }
    ];
    localStorage.setItem(STORAGE_KEYS.alerts, JSON.stringify(alerts));
  } catch (error) {
    console.error('生成预警失败:', error);
  }
}

// 通用CRUD操作
function getItem<T>(key: string): T[] {
  const data = localStorage.getItem(key);
  return data ? JSON.parse(data) : [];
}

function setItem<T>(key: string, data: T[]) {
  localStorage.setItem(key, JSON.stringify(data));
}

// 部门操作
export const getDepartments = () => getItem<Department>(STORAGE_KEYS.departments);
export const saveDepartment = (dept: Department) => {
  const depts = getDepartments();
  const index = depts.findIndex(d => d.id === dept.id);
  if (index >= 0) {
    depts[index] = dept;
  } else {
    depts.push(dept);
  }
  setItem(STORAGE_KEYS.departments, depts);
};
export const deleteDepartment = (id: string) => {
  setItem(STORAGE_KEYS.departments, getDepartments().filter(d => d.id !== id));
};

// 科目操作
export const getSubjects = () => getItem<AccountSubject>(STORAGE_KEYS.subjects);
export const saveSubject = (subject: AccountSubject) => {
  const subjects = getSubjects();
  const index = subjects.findIndex(s => s.id === subject.id);
  if (index >= 0) {
    subjects[index] = subject;
  } else {
    subjects.push(subject);
  }
  setItem(STORAGE_KEYS.subjects, subjects);
};
export const deleteSubject = (id: string) => {
  setItem(STORAGE_KEYS.subjects, getSubjects().filter(s => s.id !== id));
};

// 项目操作
export const getProjects = () => getItem<Project>(STORAGE_KEYS.projects);
export const saveProject = (project: Project) => {
  const projects = getProjects();
  const index = projects.findIndex(p => p.id === project.id);
  if (index >= 0) {
    projects[index] = project;
  } else {
    projects.push(project);
  }
  setItem(STORAGE_KEYS.projects, projects);
};
export const deleteProject = (id: string) => {
  setItem(STORAGE_KEYS.projects, getProjects().filter(p => p.id !== id));
};

// 用户操作
export const getUsers = () => getItem<User>(STORAGE_KEYS.users);
export const saveUser = (user: User) => {
  const users = getUsers();
  const index = users.findIndex(u => u.id === user.id);
  if (index >= 0) {
    users[index] = user;
  } else {
    users.push(user);
  }
  setItem(STORAGE_KEYS.users, users);
};
export const deleteUser = (id: string) => {
  setItem(STORAGE_KEYS.users, getUsers().filter(u => u.id !== id));
};

// 年度预算操作
export const getAnnualBudgets = (year?: number) => {
  const budgets = getItem<AnnualBudget>(STORAGE_KEYS.annualBudgets);
  return year ? budgets.filter(b => b.year === year) : budgets;
};
export const saveAnnualBudget = (budget: AnnualBudget) => {
  const budgets = getAnnualBudgets();
  const index = budgets.findIndex(b => b.id === budget.id);
  if (index >= 0) {
    budgets[index] = budget;
  } else {
    budgets.push(budget);
  }
  setItem(STORAGE_KEYS.annualBudgets, budgets);
};
export const deleteAnnualBudget = (id: string) => {
  setItem(STORAGE_KEYS.annualBudgets, getAnnualBudgets().filter(b => b.id !== id));
};

// 月度预算操作
export const getMonthlyBudgets = (year?: number, month?: number) => {
  const budgets = getItem<MonthlyBudget>(STORAGE_KEYS.monthlyBudgets);
  return budgets.filter(b => (!year || b.year === year) && (!month || b.month === month));
};
export const saveMonthlyBudget = (budget: MonthlyBudget) => {
  const budgets = getItem<MonthlyBudget>(STORAGE_KEYS.monthlyBudgets);
  const index = budgets.findIndex(b => b.id === budget.id);
  if (index >= 0) {
    budgets[index] = budget;
  } else {
    budgets.push(budget);
  }
  setItem(STORAGE_KEYS.monthlyBudgets, budgets);
};

// 付款计划操作
export const getPaymentPlans = (year?: number, month?: number, departmentId?: string) => {
  const plans = getItem<PaymentPlan>(STORAGE_KEYS.paymentPlans);
  return plans.filter(p => 
    (!year || p.year === year) && 
    (!month || p.month === month) &&
    (!departmentId || p.departmentId === departmentId)
  );
};
export const savePaymentPlan = (plan: PaymentPlan) => {
  const plans = getItem<PaymentPlan>(STORAGE_KEYS.paymentPlans);
  const index = plans.findIndex(p => p.id === plan.id);
  if (index >= 0) {
    plans[index] = plan;
  } else {
    plans.push(plan);
  }
  setItem(STORAGE_KEYS.paymentPlans, plans);
};
export const deletePaymentPlan = (id: string) => {
  setItem(STORAGE_KEYS.paymentPlans, getItem<PaymentPlan>(STORAGE_KEYS.paymentPlans).filter(p => p.id !== id));
};

// 实际支出操作
export const getActualExpenses = (year?: number, month?: number, departmentId?: string) => {
  const expenses = getItem<ActualExpense>(STORAGE_KEYS.actualExpenses);
  return expenses.filter(e => 
    (!year || e.year === year) && 
    (!month || e.month === month) &&
    (!departmentId || e.departmentId === departmentId)
  );
};
export const saveActualExpense = (expense: ActualExpense) => {
  const expenses = getItem<ActualExpense>(STORAGE_KEYS.actualExpenses);
  const index = expenses.findIndex(e => e.id === expense.id);
  if (index >= 0) {
    expenses[index] = expense;
  } else {
    expenses.push(expense);
  }
  setItem(STORAGE_KEYS.actualExpenses, expenses);
};
export const deleteActualExpense = (id: string) => {
  setItem(STORAGE_KEYS.actualExpenses, getItem<ActualExpense>(STORAGE_KEYS.actualExpenses).filter(e => e.id !== id));
};

// 预警操作
export const getAlerts = (departmentId?: string) => {
  const alerts = getItem<Alert>(STORAGE_KEYS.alerts);
  return alerts.filter(a => !departmentId || a.departmentId === departmentId).sort((a, b) => 
    new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
  );
};
export const saveAlert = (alert: Alert) => {
  const alerts = getItem<Alert>(STORAGE_KEYS.alerts);
  const index = alerts.findIndex(a => a.id === alert.id);
  if (index >= 0) {
    alerts[index] = alert;
  } else {
    alerts.push(alert);
  }
  setItem(STORAGE_KEYS.alerts, alerts);
};
export const markAlertAsRead = (id: string) => {
  const alerts = getItem<Alert>(STORAGE_KEYS.alerts);
  const alert = alerts.find(a => a.id === id);
  if (alert) {
    alert.isRead = true;
    alert.readAt = new Date().toISOString();
    setItem(STORAGE_KEYS.alerts, alerts);
  }
};

// 系统配置
export const getSystemConfig = (): SystemConfig => {
  const config = localStorage.getItem(STORAGE_KEYS.config);
  return config ? JSON.parse(config) : {
    companyName: '生物制药有限公司',
    fiscalYear: 2026,
    paymentPlanDeadline: 25,
    currency: 'CNY',
    budgetAlertThreshold: 90
  };
};
export const saveSystemConfig = (config: SystemConfig) => {
  localStorage.setItem(STORAGE_KEYS.config, JSON.stringify(config));
};

// 认证相关
export const login = (email: string, _password: string): User | null => {
  const users = getUsers();
  const user = users.find(u => u.email === email);
  if (user) {
    localStorage.setItem(STORAGE_KEYS.currentUser, JSON.stringify(user));
    return user;
  }
  return null;
};

export const logout = () => {
  localStorage.removeItem(STORAGE_KEYS.currentUser);
};

export const getCurrentUser = (): User | null => {
  const user = localStorage.getItem(STORAGE_KEYS.currentUser);
  return user ? JSON.parse(user) : null;
};

// 计算预算执行数据
export function calculateBudgetExecution(year: number, month?: number): BudgetExecution[] {
  const departments = getDepartments();
  const subjects = getSubjects();
  const projects = getProjects();
  const annualBudgets = getAnnualBudgets(year);
  const monthlyBudgets = getMonthlyBudgets(year, month);
  const actualExpenses = getActualExpenses(year, month);

  const executions: BudgetExecution[] = [];

  departments.forEach(dept => {
    subjects.forEach(subject => {
      projects.forEach(project => {
        const annualBudget = annualBudgets.find(
          ab => ab.departmentId === dept.id && ab.subjectId === subject.id && ab.projectId === project.id
        );
        const monthlyBudget = month ? monthlyBudgets.find(
          mb => mb.departmentId === dept.id && mb.subjectId === subject.id && mb.projectId === project.id
        ) : null;
        
        const actualExpense = actualExpenses
          .filter(ae => ae.departmentId === dept.id && ae.subjectId === subject.id && ae.projectId === project.id)
          .reduce((sum, ae) => sum + ae.amount, 0);

        const budget = month ? (monthlyBudget?.amount || 0) : (annualBudget?.amount || 0);
        const variance = actualExpense - budget;
        const varianceRate = budget > 0 ? (variance / budget) * 100 : 0;
        const executionRate = budget > 0 ? (actualExpense / budget) * 100 : 0;

        if (budget > 0 || actualExpense > 0) {
          executions.push({
            departmentId: dept.id,
            departmentName: dept.name,
            subjectId: subject.id,
            subjectName: subject.name,
            projectId: project.id,
            projectName: project.name,
            annualBudget: annualBudget?.amount || 0,
            monthlyBudget: monthlyBudget?.amount || 0,
            actualExpense,
            variance,
            varianceRate,
            executionRate,
            year,
            month: month || 0
          });
        }
      });
    });
  });

  return executions;
}

// 获取仪表盘数据
export function getDashboardData(year: number, month?: number): DashboardData {
  const executions = calculateBudgetExecution(year, month);
  const departments = getDepartments();
  const alerts = getAlerts();

  const totalBudget = executions.reduce((sum, e) => sum + (month ? e.monthlyBudget : e.annualBudget), 0);
  const totalActual = executions.reduce((sum, e) => sum + e.actualExpense, 0);
  const totalRemaining = totalBudget - totalActual;
  const overallExecutionRate = totalBudget > 0 ? (totalActual / totalBudget) * 100 : 0;

  const departmentStats: DepartmentStat[] = departments.map(dept => {
    const deptExecutions = executions.filter(e => e.departmentId === dept.id);
    const budget = deptExecutions.reduce((sum, e) => sum + (month ? e.monthlyBudget : e.annualBudget), 0);
    const actual = deptExecutions.reduce((sum, e) => sum + e.actualExpense, 0);
    return {
      departmentId: dept.id,
      departmentName: dept.name,
      budget,
      actual,
      executionRate: budget > 0 ? (actual / budget) * 100 : 0,
      variance: actual - budget
    };
  });

  // 生成月度趋势数据
  const monthlyTrend: TrendData[] = [];
  for (let m = 1; m <= (month || 12); m++) {
    const monthExecutions = calculateBudgetExecution(year, m);
    const budget = monthExecutions.reduce((sum, e) => sum + e.monthlyBudget, 0);
    const actual = monthExecutions.reduce((sum, e) => sum + e.actualExpense, 0);
    monthlyTrend.push({
      period: `${year}-${String(m).padStart(2, '0')}`,
      budget,
      actual,
      variance: actual - budget,
      executionRate: budget > 0 ? (actual / budget) * 100 : 0
    });
  }

  return {
    totalBudget,
    totalActual,
    totalRemaining,
    overallExecutionRate,
    departmentStats,
    monthlyTrend,
    alerts: alerts.slice(0, 5),
    insights: []
  };
}

// 获取项目费用分析
export function getProjectExpenseAnalysis(projectId: string, year: number): ProjectExpenseAnalysis | null {
  const project = getProjects().find(p => p.id === projectId);
  if (!project) return null;

  const departments = getDepartments();
  const executions = calculateBudgetExecution(year).filter(e => e.projectId === projectId);

  const totalBudget = executions.reduce((sum, e) => sum + e.annualBudget, 0);
  const totalActual = executions.reduce((sum, e) => sum + e.actualExpense, 0);

  const departmentBreakdown = departments.map(dept => {
    const deptExecutions = executions.filter(e => e.departmentId === dept.id);
    return {
      departmentId: dept.id,
      departmentName: dept.name,
      budget: deptExecutions.reduce((sum, e) => sum + e.annualBudget, 0),
      actual: deptExecutions.reduce((sum, e) => sum + e.actualExpense, 0)
    };
  }).filter(d => d.budget > 0 || d.actual > 0);

  const monthlyTrend: TrendData[] = [];
  for (let month = 1; month <= 12; month++) {
    const monthExecutions = calculateBudgetExecution(year, month).filter(e => e.projectId === projectId);
    const budget = monthExecutions.reduce((sum, e) => sum + e.monthlyBudget, 0);
    const actual = monthExecutions.reduce((sum, e) => sum + e.actualExpense, 0);
    monthlyTrend.push({
      period: `${year}-${String(month).padStart(2, '0')}`,
      budget,
      actual,
      variance: actual - budget,
      executionRate: budget > 0 ? (actual / budget) * 100 : 0
    });
  }

  return {
    projectId: project.id,
    projectName: project.name,
    projectCode: project.code,
    totalBudget,
    totalActual,
    totalVariance: totalActual - totalBudget,
    executionRate: totalBudget > 0 ? (totalActual / totalBudget) * 100 : 0,
    departmentBreakdown,
    monthlyTrend
  };
}

// 检查权限
export function checkPermission(user: User, module: string, action: string): boolean {
  const permissions: Record<string, Record<string, string[]>> = {
    'annual-budget': {
      full: ['admin'],
      view: ['admin', 'boss'],
      create: ['admin'],
      edit: ['admin'],
      delete: ['admin']
    },
    'payment-plan': {
      full: ['admin'],
      view: ['admin', 'boss', 'manager'],
      create: ['admin', 'manager'],
      edit: ['admin', 'manager'],
      delete: ['admin', 'manager'],
      submit: ['manager']
    },
    'actual-expense': {
      full: ['admin'],
      view: ['admin', 'boss', 'manager'],
      create: ['admin', 'manager'],
      edit: ['admin'],
      delete: ['admin']
    },
    'variance-report': {
      view: ['admin', 'boss', 'manager']
    },
    'alert': {
      view: ['admin', 'boss', 'manager']
    },
    'system-config': {
      full: ['admin'],
      view: ['admin'],
      edit: ['admin']
    },
    'ai-analysis': {
      advanced: ['admin', 'boss'],
      basic: ['manager']
    }
  };

  const modulePerms = permissions[module];
  if (!modulePerms) return false;

  const allowedRoles = modulePerms[action] || [];
  return allowedRoles.includes(user.role);
}
