import { useState, useEffect } from 'react';
import { Toaster, toast } from 'sonner';
// AuthGuard component is available but not used in current implementation
import { LoginForm } from '@/components/LoginForm';
import { Sidebar } from '@/components/Sidebar';
import { Dashboard } from '@/components/Dashboard';
import { BudgetManagement } from '@/components/BudgetManagement';
import { PaymentPlanModule } from '@/components/PaymentPlan';
import { ExpenseManagement } from '@/components/ExpenseManagement';
import { VarianceAnalysis } from '@/components/VarianceAnalysis';
import { TrendAnalysis } from '@/components/TrendAnalysis';
import { AIInsights } from '@/components/AIInsights';
import { ProjectAnalysis } from '@/components/ProjectAnalysis';
import { SystemConfigModule } from '@/components/SystemConfig';
import { initializeDefaultData } from '@/services/dataService';
import type { User } from '@/types';
import './App.css';

function App() {
  const [user, setUser] = useState<User | null>(null);
  const [activeModule, setActiveModule] = useState('dashboard');
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    try {
      // 初始化默认数据
      initializeDefaultData();
      
      // 显示欢迎提示
      toast.success('系统加载完成', {
        description: '欢迎使用BioPharma财务管理系统',
        duration: 3000
      });
    } catch (error) {
      console.error('初始化数据失败:', error);
      toast.error('系统初始化失败，请刷新页面重试');
    } finally {
      setIsLoading(false);
    }
  }, []);

  const handleLogin = (loggedInUser: User) => {
    setUser(loggedInUser);
    toast.success(`欢迎回来，${loggedInUser.name}`, {
      description: `您以${getRoleName(loggedInUser.role)}身份登录`
    });
  };

  const handleLogout = () => {
    setUser(null);
    setActiveModule('dashboard');
    toast.info('已退出登录');
  };

  const getRoleName = (role: string) => {
    switch (role) {
      case 'admin': return '管理员';
      case 'manager': return '部门经理';
      case 'boss': return '总经理';
      default: return role;
    }
  };

  const renderModule = () => {
    if (!user) return null;

    switch (activeModule) {
      case 'dashboard':
        return <Dashboard user={user} />;
      case 'budget':
        return <BudgetManagement />;
      case 'payment-plan':
        return <PaymentPlanModule user={user} />;
      case 'expense':
        return <ExpenseManagement user={user} />;
      case 'variance':
        return <VarianceAnalysis user={user} />;
      case 'trend':
        return <TrendAnalysis user={user} />;
      case 'ai-insights':
        return <AIInsights user={user} />;
      case 'project':
        return <ProjectAnalysis user={user} />;
      case 'settings':
        return <SystemConfigModule />;
      default:
        return <Dashboard user={user} />;
    }
  };

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-[#1d6a70] to-[#2c3e50]">
        <div className="text-center">
          <div className="animate-spin rounded-full h-16 w-16 border-b-2 border-white mx-auto mb-4"></div>
          <p className="text-white text-lg">系统加载中...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <Toaster 
        position="top-right" 
        richColors 
        closeButton
        toastOptions={{
          style: {
            fontFamily: 'Inter, system-ui, sans-serif'
          }
        }}
      />
      
      {!user ? (
        <LoginForm onLogin={handleLogin} />
      ) : (
        <div className="flex h-screen overflow-hidden">
          <Sidebar 
            user={user} 
            activeModule={activeModule}
            onModuleChange={setActiveModule}
            onLogout={handleLogout}
          />
          <main className="flex-1 overflow-auto">
            {renderModule()}
          </main>
        </div>
      )}
    </div>
  );
}

export default App;
