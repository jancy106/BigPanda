// 用户角色
export type UserRole = 'admin' | 'manager' | 'boss';

// 用户
export interface User {
  id: string;
  email: string;
  name: string;
  role: UserRole;
  departmentId?: string;
  avatar?: string;
}

// 部门
export interface Department {
  id: string;
  name: string;
  code: string;
  managerId?: string;
  description?: string;
}

// 预算科目
export interface AccountSubject {
  id: string;
  code: string;
  name: string;
  category: 'expense' | 'capital' | 'operating';
  parentId?: string;
  description?: string;
}

// 研发项目
export interface Project {
  id: string;
  code: string;
  name: string;
  status: 'planning' | 'ongoing' | 'completed' | 'suspended';
  startDate: string;
  endDate?: string;
  description?: string;
}

// 年度预算
export interface AnnualBudget {
  id: string;
  year: number;
  departmentId: string;
  subjectId: string;
  projectId?: string;
  amount: number;
  createdAt: string;
  updatedAt: string;
}

// 月度预算
export interface MonthlyBudget {
  id: string;
  year: number;
  month: number;
  departmentId: string;
  subjectId: string;
  projectId?: string;
  amount: number;
  createdAt: string;
  updatedAt: string;
}

// 付款计划
export interface PaymentPlan {
  id: string;
  year: number;
  month: number;
  departmentId: string;
  subjectId: string;
  projectId?: string;
  amount: number;
  description: string;
  vendor?: string;
  status: 'draft' | 'submitted' | 'approved' | 'rejected';
  submitterId: string;
  submittedAt?: string;
  approvedAt?: string;
  approverId?: string;
  remarks?: string;
}

// 实际支出
export interface ActualExpense {
  id: string;
  date: string;
  year: number;
  month: number;
  departmentId: string;
  subjectId: string;
  projectId?: string;
  amount: number;
  description: string;
  vendor?: string;
  invoiceNo?: string;
  paymentMethod: 'bank' | 'cash' | 'check' | 'other';
  recorderId: string;
  recordedAt: string;
  attachments?: string[];
}

// 预算执行统计
export interface BudgetExecution {
  departmentId: string;
  departmentName: string;
  subjectId: string;
  subjectName: string;
  projectId?: string;
  projectName?: string;
  annualBudget: number;
  monthlyBudget: number;
  actualExpense: number;
  variance: number;
  varianceRate: number;
  executionRate: number;
  year: number;
  month: number;
}

// 预警信息
export interface Alert {
  id: string;
  type: 'overspend' | 'variance' | 'deadline' | 'anomaly';
  level: 'info' | 'warning' | 'critical';
  title: string;
  message: string;
  departmentId?: string;
  projectId?: string;
  relatedData?: Record<string, any>;
  createdAt: string;
  isRead: boolean;
  readAt?: string;
}

// AI洞察
export interface AIInsight {
  id: string;
  type: 'prediction' | 'anomaly' | 'suggestion' | 'summary';
  title: string;
  content: string;
  confidence: number;
  relatedData?: Record<string, any>;
  createdAt: string;
}

// 趋势数据
export interface TrendData {
  period: string;
  budget: number;
  actual: number;
  variance: number;
  executionRate: number;
}

// 对比数据
export interface ComparisonData {
  dimension: string;
  budget: number;
  actual: number;
  variance: number;
  executionRate: number;
  children?: ComparisonData[];
}

// 仪表盘数据
export interface DashboardData {
  totalBudget: number;
  totalActual: number;
  totalRemaining: number;
  overallExecutionRate: number;
  departmentStats: DepartmentStat[];
  monthlyTrend: TrendData[];
  alerts: Alert[];
  insights: AIInsight[];
}

export interface DepartmentStat {
  departmentId: string;
  departmentName: string;
  budget: number;
  actual: number;
  executionRate: number;
  variance: number;
}

// 项目费用分析
export interface ProjectExpenseAnalysis {
  projectId: string;
  projectName: string;
  projectCode: string;
  totalBudget: number;
  totalActual: number;
  totalVariance: number;
  executionRate: number;
  departmentBreakdown: {
    departmentId: string;
    departmentName: string;
    budget: number;
    actual: number;
  }[];
  monthlyTrend: TrendData[];
}

// 权限配置
export interface PermissionConfig {
  module: string;
  admin: string[];
  manager: string[];
  boss: string[];
}

// 系统配置
export interface SystemConfig {
  companyName: string;
  fiscalYear: number;
  paymentPlanDeadline: number; // 每月截止日
  currency: string;
  budgetAlertThreshold: number; // 预警阈值百分比
}
