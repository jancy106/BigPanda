import { useEffect, useState } from 'react';
import { getCurrentUser } from '@/services/dataService';
import type { User } from '@/types';

interface AuthGuardProps {
  children: React.ReactNode;
  onLogin: (user: User) => void;
}

export function AuthGuard({ children, onLogin }: AuthGuardProps) {
  const [isLoading, setIsLoading] = useState(true);
  const [, setIsAuthenticated] = useState(false);

  useEffect(() => {
    const user = getCurrentUser();
    if (user) {
      setIsAuthenticated(true);
      onLogin(user);
    }
    setIsLoading(false);
  }, [onLogin]);

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-[#1d6a70] to-[#2c3e50]">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-white"></div>
      </div>
    );
  }

  return <>{children}</>;
}
