import { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Badge } from '@/components/ui/badge';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { 
  Plus, 
  Search, 
  Edit2, 
  Trash2, 
  Upload, 
  Download,
  FileSpreadsheet,
  CreditCard,
  Wallet
} from 'lucide-react';
import { 
  getActualExpenses, 
  getDepartments, 
  getSubjects, 
  getProjects,
  saveActualExpense,
  deleteActualExpense
} from '@/services/dataService';
import type { ActualExpense, Department, AccountSubject, Project, User } from '@/types';
import { formatCurrency } from '@/lib/utils';
import { toast } from 'sonner';
import * as XLSX from 'xlsx';

interface ExpenseManagementProps {
  user: User;
}

export function ExpenseManagement({ user }: ExpenseManagementProps) {
  const [expenses, setExpenses] = useState<ActualExpense[]>([]);
  const [departments, setDepartments] = useState<Department[]>([]);
  const [subjects, setSubjects] = useState<AccountSubject[]>([]);
  const [projects, setProjects] = useState<Project[]>([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedYear, setSelectedYear] = useState(2026);
  const [selectedMonth, setSelectedMonth] = useState(3);
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [editingExpense, setEditingExpense] = useState<Partial<ActualExpense> | null>(null);
  const [isImportDialogOpen, setIsImportDialogOpen] = useState(false);

  useEffect(() => {
    loadData();
  }, [selectedYear, selectedMonth, user]);

  const loadData = () => {
    setDepartments(getDepartments());
    setSubjects(getSubjects());
    setProjects(getProjects());
    const departmentId = user.role === 'manager' ? user.departmentId : undefined;
    setExpenses(getActualExpenses(selectedYear, selectedMonth, departmentId));
  };

  const handleSave = () => {
    if (!editingExpense?.departmentId || !editingExpense?.subjectId || !editingExpense?.amount || !editingExpense?.date) {
      toast.error('请填写完整信息');
      return;
    }

    const date = new Date(editingExpense.date);
    const expense: ActualExpense = {
      id: editingExpense.id || `ae_${Date.now()}`,
      date: editingExpense.date,
      year: date.getFullYear(),
      month: date.getMonth() + 1,
      departmentId: editingExpense.departmentId,
      subjectId: editingExpense.subjectId,
      projectId: editingExpense.projectId,
      amount: Number(editingExpense.amount),
      description: editingExpense.description || '',
      vendor: editingExpense.vendor,
      invoiceNo: editingExpense.invoiceNo,
      paymentMethod: editingExpense.paymentMethod || 'bank',
      recorderId: user.id,
      recordedAt: editingExpense.recordedAt || new Date().toISOString()
    };

    saveActualExpense(expense);
    toast.success('保存成功');
    setIsDialogOpen(false);
    setEditingExpense(null);
    loadData();
  };

  const handleDelete = (id: string) => {
    if (confirm('确定要删除这条支出记录吗？')) {
      deleteActualExpense(id);
      toast.success('删除成功');
      loadData();
    }
  };

  const handleExport = () => {
    const data = expenses.map(e => {
      const dept = departments.find(d => d.id === e.departmentId);
      const subject = subjects.find(s => s.id === e.subjectId);
      const project = projects.find(p => p.id === e.projectId);
      return {
        '日期': e.date,
        '部门': dept?.name,
        '科目': subject?.name,
        '项目': project?.name || '-',
        '金额': e.amount,
        '描述': e.description,
        '供应商': e.vendor || '-',
        '发票号': e.invoiceNo || '-',
        '付款方式': e.paymentMethod === 'bank' ? '银行转账' : e.paymentMethod === 'cash' ? '现金' : e.paymentMethod === 'check' ? '支票' : '其他'
      };
    });

    const ws = XLSX.utils.json_to_sheet(data);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, '支出记录');
    XLSX.writeFile(wb, `支出记录_${selectedYear}_${selectedMonth}.xlsx`);
    toast.success('导出成功');
  };

  const handleImport = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (e) => {
      try {
        const data = new Uint8Array(e.target?.result as ArrayBuffer);
        const workbook = XLSX.read(data, { type: 'array' });
        const sheet = workbook.Sheets[workbook.SheetNames[0]];
        const jsonData = XLSX.utils.sheet_to_json(sheet);

        let imported = 0;
        jsonData.forEach((row: any) => {
          const dept = departments.find(d => d.name === row['部门']);
          const subject = subjects.find(s => s.name === row['科目']);
          const project = projects.find(p => p.name === row['项目']);
          
          if (dept && subject && row['金额'] && row['日期']) {
            const date = new Date(row['日期']);
            const expense: ActualExpense = {
              id: `ae_${Date.now()}_${imported}`,
              date: row['日期'],
              year: date.getFullYear(),
              month: date.getMonth() + 1,
              departmentId: dept.id,
              subjectId: subject.id,
              projectId: project?.id,
              amount: Number(row['金额']),
              description: row['描述'] || '',
              vendor: row['供应商'],
              invoiceNo: row['发票号'],
              paymentMethod: 'bank',
              recorderId: user.id,
              recordedAt: new Date().toISOString()
            };
            saveActualExpense(expense);
            imported++;
          }
        });

        toast.success(`成功导入 ${imported} 条记录`);
        loadData();
        setIsImportDialogOpen(false);
      } catch (error) {
        toast.error('导入失败，请检查文件格式');
      }
    };
    reader.readAsArrayBuffer(file);
    event.target.value = '';
  };

  const filteredExpenses = expenses.filter(expense => {
    const dept = departments.find(d => d.id === expense.departmentId);
    const subject = subjects.find(s => s.id === expense.subjectId);
    return (
      dept?.name.includes(searchTerm) ||
      subject?.name.includes(searchTerm) ||
      expense.description.includes(searchTerm) ||
      expense.vendor?.includes(searchTerm)
    );
  });

  const totalExpense = filteredExpenses.reduce((sum, e) => sum + e.amount, 0);

  return (
    <div className="p-6 space-y-6 animate-in fade-in duration-500">
      {/* 页面标题 */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-[#2c3e50]">支出管理</h1>
          <p className="text-sm text-gray-500 mt-1">实际支出录入与批量导入</p>
        </div>
        <div className="flex gap-2">
          <Button variant="outline" onClick={() => setIsImportDialogOpen(true)}>
            <Upload className="h-4 w-4 mr-2" />
            导入
          </Button>
          <Button variant="outline" onClick={handleExport}>
            <Download className="h-4 w-4 mr-2" />
            导出
          </Button>
          <Button 
            onClick={() => {
              setEditingExpense({ date: new Date().toISOString().split('T')[0] });
              setIsDialogOpen(true);
            }}
            className="bg-gradient-to-r from-[#1d6a70] to-[#2a9d8f] hover:from-[#2a8a91] hover:to-[#1d6a70]"
          >
            <Plus className="h-4 w-4 mr-2" />
            新增支出
          </Button>
        </div>
      </div>

      {/* 统计卡片 */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card className="bg-gradient-to-br from-[#1d6a70] to-[#2a9d8f] text-white">
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <Wallet className="h-8 w-8 opacity-80" />
              <div>
                <p className="text-sm opacity-80">本月支出</p>
                <p className="text-2xl font-bold">{formatCurrency(totalExpense)}</p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card className="bg-gradient-to-br from-[#b1d658] to-[#7cb342] text-white">
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <FileSpreadsheet className="h-8 w-8 opacity-80" />
              <div>
                <p className="text-sm opacity-80">支出笔数</p>
                <p className="text-2xl font-bold">{filteredExpenses.length}</p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card className="bg-gradient-to-br from-[#f4a261] to-[#e76f51] text-white">
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <CreditCard className="h-8 w-8 opacity-80" />
              <div>
                <p className="text-sm opacity-80">平均单笔</p>
                <p className="text-2xl font-bold">
                  {formatCurrency(filteredExpenses.length > 0 ? totalExpense / filteredExpenses.length : 0)}
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* 筛选栏 */}
      <div className="flex gap-4">
        <div className="relative flex-1 max-w-sm">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-gray-400" />
          <Input
            placeholder="搜索部门、科目或描述..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="pl-10"
          />
        </div>
        <Select value={String(selectedYear)} onValueChange={(v) => setSelectedYear(Number(v))}>
          <SelectTrigger className="w-32">
            <SelectValue placeholder="选择年份" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="2025">2025年</SelectItem>
            <SelectItem value="2026">2026年</SelectItem>
            <SelectItem value="2027">2027年</SelectItem>
          </SelectContent>
        </Select>
        <Select value={String(selectedMonth)} onValueChange={(v) => setSelectedMonth(Number(v))}>
          <SelectTrigger className="w-32">
            <SelectValue placeholder="选择月份" />
          </SelectTrigger>
          <SelectContent>
            {Array.from({ length: 12 }, (_, i) => (
              <SelectItem key={i + 1} value={String(i + 1)}>{i + 1}月</SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      {/* 支出表格 */}
      <Card>
        <CardHeader>
          <CardTitle className="text-lg flex items-center gap-2">
            <FileSpreadsheet className="h-5 w-5 text-[#1d6a70]" />
            支出记录列表
          </CardTitle>
        </CardHeader>
        <CardContent className="p-0">
          <ScrollArea className="h-[500px]">
            <Table>
              <TableHeader className="sticky top-0 bg-white z-10">
                <TableRow>
                  <TableHead>日期</TableHead>
                  <TableHead>部门</TableHead>
                  <TableHead>科目</TableHead>
                  <TableHead>项目</TableHead>
                  <TableHead className="text-right">金额</TableHead>
                  <TableHead>描述</TableHead>
                  <TableHead className="text-right">操作</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredExpenses.map((expense) => {
                  const dept = departments.find(d => d.id === expense.departmentId);
                  const subject = subjects.find(s => s.id === expense.subjectId);
                  const project = projects.find(p => p.id === expense.projectId);
                  return (
                    <TableRow key={expense.id}>
                      <TableCell>{expense.date}</TableCell>
                      <TableCell>
                        <Badge variant="outline">{dept?.name}</Badge>
                      </TableCell>
                      <TableCell>{subject?.name}</TableCell>
                      <TableCell>
                        <span className="text-sm text-gray-500">{project?.name || '-'}</span>
                      </TableCell>
                      <TableCell className="text-right font-medium">
                        {formatCurrency(expense.amount)}
                      </TableCell>
                      <TableCell>
                        <span className="text-sm text-gray-600">{expense.description}</span>
                        {expense.vendor && (
                          <span className="text-xs text-gray-400 block">供应商: {expense.vendor}</span>
                        )}
                      </TableCell>
                      <TableCell className="text-right">
                        <Button
                          variant="ghost"
                          size="icon"
                          onClick={() => {
                            setEditingExpense(expense);
                            setIsDialogOpen(true);
                          }}
                        >
                          <Edit2 className="h-4 w-4" />
                        </Button>
                        <Button
                          variant="ghost"
                          size="icon"
                          onClick={() => handleDelete(expense.id)}
                        >
                          <Trash2 className="h-4 w-4 text-red-500" />
                        </Button>
                      </TableCell>
                    </TableRow>
                  );
                })}
              </TableBody>
            </Table>
          </ScrollArea>
        </CardContent>
      </Card>

      {/* 编辑对话框 */}
      <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
        <DialogContent className="max-w-lg">
          <DialogHeader>
            <DialogTitle>{editingExpense?.id ? '编辑支出' : '新增支出'}</DialogTitle>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <Label>日期</Label>
              <Input
                type="date"
                value={editingExpense?.date || ''}
                onChange={(e) => setEditingExpense({...editingExpense, date: e.target.value})}
              />
            </div>
            <div className="space-y-2">
              <Label>部门</Label>
              <Select 
                value={editingExpense?.departmentId} 
                onValueChange={(v) => setEditingExpense({...editingExpense, departmentId: v})}
              >
                <SelectTrigger>
                  <SelectValue placeholder="选择部门" />
                </SelectTrigger>
                <SelectContent>
                  {departments
                    .filter(d => user.role === 'admin' || d.id === user.departmentId)
                    .map(dept => (
                      <SelectItem key={dept.id} value={dept.id}>{dept.name}</SelectItem>
                    ))}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label>预算科目</Label>
              <Select 
                value={editingExpense?.subjectId} 
                onValueChange={(v) => setEditingExpense({...editingExpense, subjectId: v})}
              >
                <SelectTrigger>
                  <SelectValue placeholder="选择科目" />
                </SelectTrigger>
                <SelectContent>
                  {subjects.map(subject => (
                    <SelectItem key={subject.id} value={subject.id}>{subject.name}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label>项目（可选）</Label>
              <Select 
                value={editingExpense?.projectId || 'none'} 
                onValueChange={(v) => setEditingExpense({...editingExpense, projectId: v === 'none' ? undefined : v})}
              >
                <SelectTrigger>
                  <SelectValue placeholder="选择项目" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="none">无项目</SelectItem>
                  {projects.map(project => (
                    <SelectItem key={project.id} value={project.id}>{project.name}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label>支出金额</Label>
              <Input
                type="number"
                placeholder="请输入支出金额"
                value={editingExpense?.amount || ''}
                onChange={(e) => setEditingExpense({...editingExpense, amount: Number(e.target.value)})}
              />
            </div>
            <div className="space-y-2">
              <Label>支出说明</Label>
              <Input
                placeholder="请输入支出说明"
                value={editingExpense?.description || ''}
                onChange={(e) => setEditingExpense({...editingExpense, description: e.target.value})}
              />
            </div>
            <div className="space-y-2">
              <Label>供应商（可选）</Label>
              <Input
                placeholder="请输入供应商名称"
                value={editingExpense?.vendor || ''}
                onChange={(e) => setEditingExpense({...editingExpense, vendor: e.target.value})}
              />
            </div>
            <div className="space-y-2">
              <Label>发票号（可选）</Label>
              <Input
                placeholder="请输入发票号"
                value={editingExpense?.invoiceNo || ''}
                onChange={(e) => setEditingExpense({...editingExpense, invoiceNo: e.target.value})}
              />
            </div>
            <div className="space-y-2">
              <Label>付款方式</Label>
              <Select 
                value={editingExpense?.paymentMethod || 'bank'} 
                onValueChange={(v: any) => setEditingExpense({...editingExpense, paymentMethod: v})}
              >
                <SelectTrigger>
                  <SelectValue placeholder="选择付款方式" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="bank">银行转账</SelectItem>
                  <SelectItem value="cash">现金</SelectItem>
                  <SelectItem value="check">支票</SelectItem>
                  <SelectItem value="other">其他</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
          <div className="flex justify-end gap-2">
            <Button variant="outline" onClick={() => setIsDialogOpen(false)}>取消</Button>
            <Button onClick={handleSave} className="bg-[#1d6a70] hover:bg-[#2a8a91]">保存</Button>
          </div>
        </DialogContent>
      </Dialog>

      {/* 导入对话框 */}
      <Dialog open={isImportDialogOpen} onOpenChange={setIsImportDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>批量导入支出记录</DialogTitle>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div className="border-2 border-dashed border-gray-300 rounded-lg p-8 text-center">
              <Upload className="h-12 w-12 mx-auto text-gray-400 mb-4" />
              <p className="text-sm text-gray-600 mb-2">点击或拖拽Excel文件到此处</p>
              <p className="text-xs text-gray-400">支持 .xlsx, .xls 格式</p>
              <input
                type="file"
                accept=".xlsx,.xls"
                onChange={handleImport}
                className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
              />
            </div>
            <div className="bg-gray-50 p-4 rounded-lg">
              <p className="text-sm font-medium mb-2">导入模板格式：</p>
              <p className="text-xs text-gray-500">日期 | 部门 | 科目 | 项目 | 金额 | 描述 | 供应商 | 发票号</p>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
