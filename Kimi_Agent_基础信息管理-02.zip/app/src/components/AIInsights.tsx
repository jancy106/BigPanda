import { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { ScrollArea } from '@/components/ui/scroll-area';
import { 
  Brain, 
  TrendingUp, 
  AlertTriangle, 
  Lightbulb,
  Sparkles,
  Zap,
  BarChart3,
  MessageCircle,
  Send,
  Loader2
} from 'lucide-react';
import { 
  calculateBudgetExecution, 
  getDashboardData, 
  getDepartments, 
  getActualExpenses
} from '@/services/dataService';
import type { AIInsight, User } from '@/types';
import { formatCurrency } from '@/lib/utils';
// Toast notifications available for future use
import { Input } from '@/components/ui/input';

interface AIInsightsProps {
  user: User;
}

interface ChatMessage {
  role: 'user' | 'assistant';
  content: string;
  timestamp: Date;
}

export function AIInsights({ user }: AIInsightsProps) {
  const [activeTab, setActiveTab] = useState('overview');
  const [insights, setInsights] = useState<AIInsight[]>([]);
  const [chatMessages, setChatMessages] = useState<ChatMessage[]>([]);
  const [chatInput, setChatInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [predictionData, setPredictionData] = useState<any[]>([]);

  useEffect(() => {
    generateInsights();
    generatePredictions();
  }, [user]);

  const generateInsights = () => {
    const dashboardData = getDashboardData(2026, 3);
    const executions = calculateBudgetExecution(2026, 3);
    const newInsights: AIInsight[] = [];

    // 1. 超支预警
    const overspendItems = executions.filter(e => e.variance > 0 && e.varianceRate > 10);
    if (overspendItems.length > 0) {
      const topOverspend = overspendItems.sort((a, b) => b.variance - a.variance)[0];
      newInsights.push({
        id: `insight_${Date.now()}_1`,
        type: 'anomaly',
        title: '超支风险预警',
        content: `${topOverspend.departmentName}的${topOverspend.subjectName}已超支${topOverspend.varianceRate.toFixed(1)}%，建议立即审查并调整后续支出计划。`,
        confidence: 0.92,
        createdAt: new Date().toISOString()
      });
    }

    // 2. 执行率分析
    const lowExecutionDepts = dashboardData.departmentStats.filter(d => d.executionRate < 50);
    if (lowExecutionDepts.length > 0) {
      newInsights.push({
        id: `insight_${Date.now()}_2`,
        type: 'summary',
        title: '预算执行进度提醒',
        content: `${lowExecutionDepts.length}个部门执行率低于50%，建议加快项目进度或调整预算分配。`,
        confidence: 0.85,
        createdAt: new Date().toISOString()
      });
    }

    // 3. 趋势预测
    const monthlyTrend = dashboardData.monthlyTrend;
    if (monthlyTrend.length >= 2) {
      const lastMonth = monthlyTrend[monthlyTrend.length - 1];
      const prevMonth = monthlyTrend[monthlyTrend.length - 2];
      const growthRate = prevMonth.actual > 0 
        ? ((lastMonth.actual - prevMonth.actual) / prevMonth.actual) * 100 
        : 0;
      
      if (Math.abs(growthRate) > 20) {
        newInsights.push({
          id: `insight_${Date.now()}_3`,
          type: 'prediction',
          title: '支出趋势异常',
          content: `本月支出较上月${growthRate > 0 ? '增长' : '下降'}${Math.abs(growthRate).toFixed(1)}%，请关注支出波动原因。`,
          confidence: 0.78,
          createdAt: new Date().toISOString()
        });
      }
    }

    // 4. 优化建议
    const highVarianceItems = executions.filter(e => Math.abs(e.varianceRate) > 30);
    if (highVarianceItems.length > 0) {
      newInsights.push({
        id: `insight_${Date.now()}_4`,
        type: 'suggestion',
        title: '预算优化建议',
        content: `发现${highVarianceItems.length}项预算偏差超过30%，建议重新评估预算编制的准确性，考虑引入滚动预算机制。`,
        confidence: 0.88,
        createdAt: new Date().toISOString()
      });
    }

    // 5. 部门对比分析
    const deptStats = dashboardData.departmentStats;
    const maxExecution = deptStats.reduce((max, d) => d.executionRate > max.executionRate ? d : max, deptStats[0]);
    const minExecution = deptStats.reduce((min, d) => d.executionRate < min.executionRate ? d : min, deptStats[0]);
    
    if (maxExecution && minExecution && maxExecution.executionRate - minExecution.executionRate > 40) {
      newInsights.push({
        id: `insight_${Date.now()}_5`,
        type: 'summary',
        title: '部门执行差异分析',
        content: `${maxExecution.departmentName}执行率(${maxExecution.executionRate.toFixed(1)}%)与${minExecution.departmentName}执行率(${minExecution.executionRate.toFixed(1)}%)差异显著，建议分析原因并分享最佳实践。`,
        confidence: 0.82,
        createdAt: new Date().toISOString()
      });
    }

    setInsights(newInsights);
  };

  const generatePredictions = () => {
    const expenses = getActualExpenses(2026);
    const predictions: any[] = [];
    
    // 按部门预测下月支出
    const departments = getDepartments();
    departments.forEach(dept => {
      const deptExpenses = expenses.filter(e => e.departmentId === dept.id);
      const monthlyTotals: Record<number, number> = {};
      
      deptExpenses.forEach(e => {
        monthlyTotals[e.month] = (monthlyTotals[e.month] || 0) + e.amount;
      });
      
      const months = Object.keys(monthlyTotals).map(Number).sort();
      if (months.length >= 2) {
        const lastMonth = monthlyTotals[months[months.length - 1]];
        const prevMonth = monthlyTotals[months[months.length - 2]];
        const trend = lastMonth - prevMonth;
        const predicted = lastMonth + trend * 0.5; // 简单线性预测
        
        predictions.push({
          department: dept.name,
          lastMonth,
          predicted: Math.max(0, predicted),
          trend: trend > 0 ? 'up' : 'down'
        });
      }
    });
    
    setPredictionData(predictions.slice(0, 5));
  };

  const handleChatSubmit = async () => {
    if (!chatInput.trim()) return;

    const userMessage: ChatMessage = {
      role: 'user',
      content: chatInput,
      timestamp: new Date()
    };

    setChatMessages(prev => [...prev, userMessage]);
    setChatInput('');
    setIsLoading(true);

    // 模拟AI响应
    await new Promise(resolve => setTimeout(resolve, 1000));

    let response = '';
    const input = userMessage.content.toLowerCase();

    if (input.includes('预算') && input.includes('够')) {
      const deptMatch = input.match(/(.+?)部/);
      if (deptMatch) {
        const deptName = deptMatch[1];
        const departments = getDepartments();
        const dept = departments.find(d => d.name.includes(deptName));
        if (dept) {
          const executions = calculateBudgetExecution(2026, 3).filter(e => e.departmentId === dept.id);
          const totalBudget = executions.reduce((sum, e) => sum + e.monthlyBudget, 0);
          const totalActual = executions.reduce((sum, e) => sum + e.actualExpense, 0);
          const remaining = totalBudget - totalActual;
          const executionRate = totalBudget > 0 ? (totalActual / totalBudget) * 100 : 0;
          
          response = `${dept.name}本月预算${formatCurrency(totalBudget)}，已执行${formatCurrency(totalActual)}，执行率${executionRate.toFixed(1)}%。${remaining > 0 ? `剩余预算${formatCurrency(remaining)}。` : '预算已超支，请关注。'}`;
        } else {
          response = '未找到该部门信息，请确认部门名称。';
        }
      } else {
        const dashboardData = getDashboardData(2026, 3);
        response = `公司整体预算${formatCurrency(dashboardData.totalBudget)}，已执行${formatCurrency(dashboardData.totalActual)}，整体执行率${dashboardData.overallExecutionRate.toFixed(1)}%。`;
      }
    } else if (input.includes('超支')) {
      const executions = calculateBudgetExecution(2026, 3).filter(e => e.variance > 0);
      if (executions.length > 0) {
        const top3 = executions.sort((a, b) => b.variance - a.variance).slice(0, 3);
        response = `本月有${executions.length}项超支。超支最多的三项是：\n${top3.map((e, i) => `${i + 1}. ${e.departmentName}-${e.subjectName}: ${formatCurrency(e.variance)}`).join('\n')}`;
      } else {
        response = '本月暂无超支项目，预算控制良好。';
      }
    } else if (input.includes('建议') || input.includes('优化')) {
      response = '基于当前数据分析，我有以下建议：\n1. 关注执行率低于50%的部门，加快项目进度\n2. 对偏差超过30%的预算项进行重新评估\n3. 考虑引入滚动预算机制提高预算准确性\n4. 加强部门间最佳实践分享';
    } else {
      response = '我是您的AI财务助手，可以帮您分析预算执行情况、预测支出趋势、提供优化建议。您可以问我：\n- "研发部预算够吗？"\n- "有哪些超支项目？"\n- "有什么优化建议？"';
    }

    const assistantMessage: ChatMessage = {
      role: 'assistant',
      content: response,
      timestamp: new Date()
    };

    setChatMessages(prev => [...prev, assistantMessage]);
    setIsLoading(false);
  };

  const getInsightIcon = (type: string) => {
    switch (type) {
      case 'prediction':
        return <TrendingUp className="h-5 w-5 text-blue-500" />;
      case 'anomaly':
        return <AlertTriangle className="h-5 w-5 text-red-500" />;
      case 'suggestion':
        return <Lightbulb className="h-5 w-5 text-yellow-500" />;
      default:
        return <BarChart3 className="h-5 w-5 text-green-500" />;
    }
  };

  const getInsightColor = (type: string) => {
    switch (type) {
      case 'prediction':
        return 'bg-blue-50 border-blue-200';
      case 'anomaly':
        return 'bg-red-50 border-red-200';
      case 'suggestion':
        return 'bg-yellow-50 border-yellow-200';
      default:
        return 'bg-green-50 border-green-200';
    }
  };

  return (
    <div className="p-6 space-y-6 animate-in fade-in duration-500">
      {/* 页面标题 */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-[#2c3e50]">AI智能洞察</h1>
          <p className="text-sm text-gray-500 mt-1">基于数据的智能分析与建议</p>
        </div>
        <div className="flex items-center gap-2">
          <Sparkles className="h-5 w-5 text-[#f4a261]" />
          <span className="text-sm text-gray-500">AI驱动</span>
        </div>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList className="grid w-full max-w-md grid-cols-3">
          <TabsTrigger value="overview">洞察概览</TabsTrigger>
          <TabsTrigger value="prediction">预测分析</TabsTrigger>
          <TabsTrigger value="chat">智能问答</TabsTrigger>
        </TabsList>

        <TabsContent value="overview" className="space-y-6">
          {/* 洞察卡片 */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {insights.map((insight) => (
              <Card key={insight.id} className={`border-l-4 ${getInsightColor(insight.type)}`}>
                <CardContent className="p-4">
                  <div className="flex items-start gap-3">
                    <div className="p-2 rounded-lg bg-white shadow-sm">
                      {getInsightIcon(insight.type)}
                    </div>
                    <div className="flex-1">
                      <div className="flex items-center gap-2 mb-1">
                        <h3 className="font-semibold text-[#2c3e50]">{insight.title}</h3>
                        <Badge variant="secondary" className="text-xs">
                          置信度 {(insight.confidence * 100).toFixed(0)}%
                        </Badge>
                      </div>
                      <p className="text-sm text-gray-600">{insight.content}</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>

          {/* 功能特性 */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <Card className="hover:shadow-lg transition-shadow">
              <CardContent className="p-6 text-center">
                <div className="w-12 h-12 rounded-full bg-red-100 flex items-center justify-center mx-auto mb-4">
                  <AlertTriangle className="h-6 w-6 text-red-500" />
                </div>
                <h3 className="font-semibold mb-2">差异预警</h3>
                <p className="text-sm text-gray-500">自动识别超支和异常偏差</p>
              </CardContent>
            </Card>
            <Card className="hover:shadow-lg transition-shadow">
              <CardContent className="p-6 text-center">
                <div className="w-12 h-12 rounded-full bg-blue-100 flex items-center justify-center mx-auto mb-4">
                  <TrendingUp className="h-6 w-6 text-blue-500" />
                </div>
                <h3 className="font-semibold mb-2">趋势预测</h3>
                <p className="text-sm text-gray-500">基于历史数据预测未来支出</p>
              </CardContent>
            </Card>
            <Card className="hover:shadow-lg transition-shadow">
              <CardContent className="p-6 text-center">
                <div className="w-12 h-12 rounded-full bg-yellow-100 flex items-center justify-center mx-auto mb-4">
                  <Lightbulb className="h-6 w-6 text-yellow-500" />
                </div>
                <h3 className="font-semibold mb-2">智能建议</h3>
                <p className="text-sm text-gray-500">基于最佳实践的优化建议</p>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="prediction" className="space-y-6">
          {/* 预测分析 */}
          <Card>
            <CardHeader>
              <CardTitle className="text-lg flex items-center gap-2">
                <TrendingUp className="h-5 w-5 text-[#1d6a70]" />
                下月支出预测
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {predictionData.map((pred, index) => (
                  <div key={index} className="flex items-center gap-4 p-4 bg-gray-50 rounded-lg">
                    <div className={`p-2 rounded-full ${pred.trend === 'up' ? 'bg-red-100' : 'bg-green-100'}`}>
                      {pred.trend === 'up' ? (
                        <TrendingUp className={`h-5 w-5 ${pred.trend === 'up' ? 'text-red-500' : 'text-green-500'}`} />
                      ) : (
                        <TrendingUp className="h-5 w-5 text-green-500 rotate-180" />
                      )}
                    </div>
                    <div className="flex-1">
                      <p className="font-medium">{pred.department}</p>
                      <p className="text-sm text-gray-500">
                        上月: {formatCurrency(pred.lastMonth, true)} → 
                        预测: {formatCurrency(pred.predicted, true)}
                      </p>
                    </div>
                    <Badge variant={pred.trend === 'up' ? 'destructive' : 'default'} className={pred.trend === 'down' ? 'bg-green-500' : ''}>
                      {pred.trend === 'up' ? '上升' : '下降'}
                    </Badge>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* 预测说明 */}
          <Card className="bg-gradient-to-br from-[#1d6a70]/5 to-[#b1d658]/5">
            <CardContent className="p-6">
              <div className="flex items-start gap-3">
                <Zap className="h-5 w-5 text-[#f4a261] mt-0.5" />
                <div>
                  <h3 className="font-semibold mb-2">预测模型说明</h3>
                  <p className="text-sm text-gray-600">
                    基于过去3个月的历史支出数据，采用线性回归算法预测下月支出趋势。
                    预测结果仅供参考，实际支出可能受项目进度、市场变化等因素影响。
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="chat" className="space-y-6">
          {/* 智能问答 */}
          <Card className="h-[600px] flex flex-col">
            <CardHeader>
              <CardTitle className="text-lg flex items-center gap-2">
                <MessageCircle className="h-5 w-5 text-[#1d6a70]" />
                AI财务助手
              </CardTitle>
            </CardHeader>
            <CardContent className="flex-1 flex flex-col">
              <ScrollArea className="flex-1 pr-4">
                <div className="space-y-4">
                  {chatMessages.length === 0 && (
                    <div className="text-center py-8 text-gray-400">
                      <Brain className="h-12 w-12 mx-auto mb-2 opacity-50" />
                      <p>我是您的AI财务助手</p>
                      <p className="text-sm mt-2">可以问我：</p>
                      <div className="flex flex-wrap gap-2 justify-center mt-2">
                        {['研发部预算够吗？', '有哪些超支项目？', '有什么优化建议？'].map(q => (
                          <button
                            key={q}
                            onClick={() => {
                              setChatInput(q);
                            }}
                            className="px-3 py-1 text-xs bg-gray-100 hover:bg-gray-200 rounded-full transition-colors"
                          >
                            {q}
                          </button>
                        ))}
                      </div>
                    </div>
                  )}
                  {chatMessages.map((msg, index) => (
                    <div
                      key={index}
                      className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}
                    >
                      <div
                        className={`max-w-[80%] p-3 rounded-lg ${
                          msg.role === 'user'
                            ? 'bg-[#1d6a70] text-white'
                            : 'bg-gray-100 text-gray-800'
                        }`}
                      >
                        <p className="text-sm whitespace-pre-line">{msg.content}</p>
                        <p className={`text-xs mt-1 ${msg.role === 'user' ? 'text-white/60' : 'text-gray-400'}`}>
                          {msg.timestamp.toLocaleTimeString('zh-CN', { hour: '2-digit', minute: '2-digit' })}
                        </p>
                      </div>
                    </div>
                  ))}
                  {isLoading && (
                    <div className="flex justify-start">
                      <div className="bg-gray-100 p-3 rounded-lg flex items-center gap-2">
                        <Loader2 className="h-4 w-4 animate-spin" />
                        <span className="text-sm text-gray-500">思考中...</span>
                      </div>
                    </div>
                  )}
                </div>
              </ScrollArea>
              <div className="flex gap-2 mt-4 pt-4 border-t">
                <Input
                  placeholder="输入您的问题..."
                  value={chatInput}
                  onChange={(e) => setChatInput(e.target.value)}
                  onKeyDown={(e) => e.key === 'Enter' && handleChatSubmit()}
                />
                <Button onClick={handleChatSubmit} disabled={isLoading}>
                  <Send className="h-4 w-4" />
                </Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
