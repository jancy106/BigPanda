import { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { ScrollArea } from '@/components/ui/scroll-area';
import { 
  FolderGit2, 
  Wallet, 
  TrendingUp, 
  AlertTriangle,
  Building2,
  Calendar,
  Download,
  BarChart3
} from 'lucide-react';
import { 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer,
  LineChart,
  Line,
  Legend,
  PieChart,
  Pie,
  Cell
} from 'recharts';
import { getProjectExpenseAnalysis, getProjects } from '@/services/dataService';
import type { ProjectExpenseAnalysis, User } from '@/types';
import { formatCurrency } from '@/lib/utils';
import { toast } from 'sonner';
import * as XLSX from 'xlsx';

interface ProjectAnalysisProps {
  user: User;
}

const COLORS = ['#1d6a70', '#b1d658', '#f4a261', '#e76f51', '#2a9d8f', '#264653', '#7cb342', '#9c27b0'];

export function ProjectAnalysis(_props: ProjectAnalysisProps) {
  const [selectedProject, setSelectedProject] = useState<string>('');
  const [selectedYear, setSelectedYear] = useState(2026);
  const [projects, setProjects] = useState<{id: string, name: string, code: string}[]>([]);
  const [analysis, setAnalysis] = useState<ProjectExpenseAnalysis | null>(null);
  const [allProjectsAnalysis, setAllProjectsAnalysis] = useState<ProjectExpenseAnalysis[]>([]);

  useEffect(() => {
    const projList = getProjects();
    setProjects(projList);
    if (projList.length > 0 && !selectedProject) {
      setSelectedProject(projList[0].id);
    }
  }, []);

  useEffect(() => {
    if (selectedProject) {
      const data = getProjectExpenseAnalysis(selectedProject, selectedYear);
      setAnalysis(data);
    }
  }, [selectedProject, selectedYear]);

  useEffect(() => {
    // 加载所有项目分析用于对比
    const allAnalysis: ProjectExpenseAnalysis[] = [];
    projects.forEach(proj => {
      const data = getProjectExpenseAnalysis(proj.id, selectedYear);
      if (data) {
        allAnalysis.push(data);
      }
    });
    setAllProjectsAnalysis(allAnalysis);
  }, [projects, selectedYear]);

  const handleExport = () => {
    if (!analysis) return;

    const data = analysis.departmentBreakdown.map(d => ({
      '项目': analysis.projectName,
      '部门': d.departmentName,
      '预算': d.budget,
      '实际': d.actual,
      '差异': d.actual - d.budget
    }));

    const ws = XLSX.utils.json_to_sheet(data);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, '项目费用分析');
    XLSX.writeFile(wb, `项目费用分析_${analysis.projectCode}_${selectedYear}.xlsx`);
    toast.success('导出成功');
  };

  const chartData = analysis?.departmentBreakdown.map(d => ({
    name: d.departmentName,
    budget: d.budget,
    actual: d.actual,
    variance: d.actual - d.budget
  })) || [];

  const projectComparisonData = allProjectsAnalysis
    .sort((a, b) => b.totalActual - a.totalActual)
    .slice(0, 8)
    .map(p => ({
      name: p.projectCode,
      fullName: p.projectName,
      budget: p.totalBudget,
      actual: p.totalActual,
      executionRate: p.executionRate
    }));

  return (
    <div className="p-6 space-y-6 animate-in fade-in duration-500">
      {/* 页面标题 */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-[#2c3e50]">项目费用分析</h1>
          <p className="text-sm text-gray-500 mt-1">按项目维度分析预算执行情况</p>
        </div>
        {analysis && (
          <Button variant="outline" onClick={handleExport}>
            <Download className="h-4 w-4 mr-2" />
            导出分析
          </Button>
        )}
      </div>

      {/* 筛选栏 */}
      <div className="flex flex-wrap gap-4">
        <Select value={String(selectedYear)} onValueChange={(v) => setSelectedYear(Number(v))}>
          <SelectTrigger className="w-32">
            <Calendar className="h-4 w-4 mr-2" />
            <SelectValue placeholder="选择年份" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="2025">2025年</SelectItem>
            <SelectItem value="2026">2026年</SelectItem>
            <SelectItem value="2027">2027年</SelectItem>
          </SelectContent>
        </Select>
        <Select value={selectedProject} onValueChange={setSelectedProject}>
          <SelectTrigger className="w-64">
            <FolderGit2 className="h-4 w-4 mr-2" />
            <SelectValue placeholder="选择项目" />
          </SelectTrigger>
          <SelectContent>
            {projects.map(proj => (
              <SelectItem key={proj.id} value={proj.id}>
                {proj.code} - {proj.name}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      {analysis && (
        <>
          {/* 项目概览卡片 */}
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <Card className="bg-gradient-to-br from-[#1d6a70] to-[#2a9d8f] text-white">
              <CardContent className="p-4">
                <div className="flex items-center gap-3">
                  <Wallet className="h-8 w-8 opacity-80" />
                  <div>
                    <p className="text-sm opacity-80">项目总预算</p>
                    <p className="text-2xl font-bold">{formatCurrency(analysis.totalBudget)}</p>
                  </div>
                </div>
              </CardContent>
            </Card>
            <Card className="bg-gradient-to-br from-[#b1d658] to-[#7cb342] text-white">
              <CardContent className="p-4">
                <div className="flex items-center gap-3">
                  <TrendingUp className="h-8 w-8 opacity-80" />
                  <div>
                    <p className="text-sm opacity-80">实际支出</p>
                    <p className="text-2xl font-bold">{formatCurrency(analysis.totalActual)}</p>
                  </div>
                </div>
              </CardContent>
            </Card>
            <Card className={`${analysis.totalVariance > 0 ? 'bg-gradient-to-br from-red-500 to-red-600' : 'bg-gradient-to-br from-green-500 to-green-600'} text-white`}>
              <CardContent className="p-4">
                <div className="flex items-center gap-3">
                  <AlertTriangle className="h-8 w-8 opacity-80" />
                  <div>
                    <p className="text-sm opacity-80">预算差异</p>
                    <p className="text-2xl font-bold">
                      {analysis.totalVariance > 0 ? '+' : ''}{formatCurrency(analysis.totalVariance)}
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
            <Card className="bg-gradient-to-br from-[#f4a261] to-[#e76f51] text-white">
              <CardContent className="p-4">
                <div className="flex items-center gap-3">
                  <BarChart3 className="h-8 w-8 opacity-80" />
                  <div>
                    <p className="text-sm opacity-80">执行率</p>
                    <p className="text-2xl font-bold">{analysis.executionRate.toFixed(1)}%</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* 预警提示 */}
          {analysis.totalVariance > 0 && (
            <Card className="border-red-200 bg-red-50">
              <CardContent className="p-4 flex items-center gap-3">
                <AlertTriangle className="h-8 w-8 text-red-500" />
                <div>
                  <p className="font-medium text-red-800">项目超支预警</p>
                  <p className="text-sm text-red-600">
                    {analysis.projectName}已超支{formatCurrency(analysis.totalVariance)}，超支率{((analysis.totalVariance / analysis.totalBudget) * 100).toFixed(1)}%
                  </p>
                </div>
              </CardContent>
            </Card>
          )}

          <Tabs defaultValue="department">
            <TabsList className="grid w-full max-w-md grid-cols-3">
              <TabsTrigger value="department">部门分布</TabsTrigger>
              <TabsTrigger value="trend">月度趋势</TabsTrigger>
              <TabsTrigger value="comparison">项目对比</TabsTrigger>
            </TabsList>

            <TabsContent value="department" className="space-y-6">
              {/* 部门分布图表 */}
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                <Card>
                  <CardHeader>
                    <CardTitle className="text-lg flex items-center gap-2">
                      <Building2 className="h-5 w-5 text-[#1d6a70]" />
                      部门费用分布
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="h-80">
                      <ResponsiveContainer width="100%" height="100%">
                        <BarChart data={chartData}>
                          <CartesianGrid strokeDasharray="3 3" stroke="#e0e0e0" />
                          <XAxis dataKey="name" tick={{ fontSize: 11 }} />
                          <YAxis tickFormatter={(value) => formatCurrency(value, true)} />
                          <Tooltip formatter={(value: number) => formatCurrency(value)} />
                          <Legend />
                          <Bar dataKey="budget" name="预算" fill="#1d6a70" />
                          <Bar dataKey="actual" name="实际" fill="#b1d658" />
                        </BarChart>
                      </ResponsiveContainer>
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle className="text-lg flex items-center gap-2">
                      <Wallet className="h-5 w-5 text-[#1d6a70]" />
                      部门费用占比
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="h-64">
                      <ResponsiveContainer width="100%" height="100%">
                        <PieChart>
                          <Pie
                            data={analysis.departmentBreakdown}
                            cx="50%"
                            cy="50%"
                            innerRadius={60}
                            outerRadius={80}
                            paddingAngle={5}
                            dataKey="actual"
                            nameKey="departmentName"
                          >
                            {analysis.departmentBreakdown.map((_entry, index) => (
                              <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                            ))}
                          </Pie>
                          <Tooltip formatter={(value: number) => formatCurrency(value)} />
                        </PieChart>
                      </ResponsiveContainer>
                    </div>
                    <div className="mt-4 space-y-2">
                      {analysis.departmentBreakdown.map((dept, index) => (
                        <div key={dept.departmentId} className="flex items-center justify-between text-sm">
                          <div className="flex items-center gap-2">
                            <div 
                              className="w-3 h-3 rounded-full" 
                              style={{ backgroundColor: COLORS[index % COLORS.length] }}
                            />
                            <span className="text-gray-600">{dept.departmentName}</span>
                          </div>
                          <span className="font-medium">{formatCurrency(dept.actual, true)}</span>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              </div>

              {/* 部门明细表格 */}
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">部门费用明细</CardTitle>
                </CardHeader>
                <CardContent className="p-0">
                  <ScrollArea className="h-[300px]">
                    <table className="w-full">
                      <thead className="sticky top-0 bg-white z-10">
                        <tr className="border-b">
                          <th className="text-left p-4 font-medium">部门</th>
                          <th className="text-right p-4 font-medium">预算</th>
                          <th className="text-right p-4 font-medium">实际</th>
                          <th className="text-right p-4 font-medium">差异</th>
                          <th className="text-right p-4 font-medium">执行率</th>
                        </tr>
                      </thead>
                      <tbody>
                        {analysis.departmentBreakdown.map((dept) => {
                          const variance = dept.actual - dept.budget;
                          const executionRate = dept.budget > 0 ? (dept.actual / dept.budget) * 100 : 0;
                          return (
                            <tr key={dept.departmentId} className="border-b hover:bg-gray-50">
                              <td className="p-4">
                                <Badge variant="outline">{dept.departmentName}</Badge>
                              </td>
                              <td className="text-right p-4">{formatCurrency(dept.budget, true)}</td>
                              <td className="text-right p-4 font-medium">{formatCurrency(dept.actual, true)}</td>
                              <td className={`text-right p-4 font-medium ${variance > 0 ? 'text-red-600' : 'text-green-600'}`}>
                                {variance > 0 ? '+' : ''}{formatCurrency(variance, true)}
                              </td>
                              <td className="text-right p-4">
                                <span className={`font-medium ${
                                  executionRate > 100 ? 'text-red-600' : 
                                  executionRate > 80 ? 'text-yellow-600' : 'text-green-600'
                                }`}>
                                  {executionRate.toFixed(1)}%
                                </span>
                              </td>
                            </tr>
                          );
                        })}
                      </tbody>
                    </table>
                  </ScrollArea>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="trend" className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg flex items-center gap-2">
                    <TrendingUp className="h-5 w-5 text-[#1d6a70]" />
                    月度支出趋势
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="h-80">
                    <ResponsiveContainer width="100%" height="100%">
                      <LineChart data={analysis.monthlyTrend}>
                        <CartesianGrid strokeDasharray="3 3" stroke="#e0e0e0" />
                        <XAxis dataKey="period" />
                        <YAxis tickFormatter={(value) => formatCurrency(value, true)} />
                        <Tooltip formatter={(value: number) => formatCurrency(value)} />
                        <Legend />
                        <Line type="monotone" dataKey="budget" name="预算" stroke="#1d6a70" strokeWidth={2} />
                        <Line type="monotone" dataKey="actual" name="实际" stroke="#b1d658" strokeWidth={2} />
                      </LineChart>
                    </ResponsiveContainer>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="comparison" className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg flex items-center gap-2">
                    <BarChart3 className="h-5 w-5 text-[#1d6a70]" />
                    项目支出对比
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="h-80">
                    <ResponsiveContainer width="100%" height="100%">
                      <BarChart data={projectComparisonData} layout="vertical">
                        <CartesianGrid strokeDasharray="3 3" stroke="#e0e0e0" />
                        <XAxis type="number" tickFormatter={(value) => formatCurrency(value, true)} />
                        <YAxis type="category" dataKey="name" width={80} />
                        <Tooltip 
                          formatter={(value: number, name: string) => [formatCurrency(value), name]}
                          labelFormatter={(label) => {
                            const item = projectComparisonData.find(d => d.name === label);
                            return item?.fullName || label;
                          }}
                        />
                        <Legend />
                        <Bar dataKey="budget" name="预算" fill="#1d6a70" />
                        <Bar dataKey="actual" name="实际" fill="#b1d658" />
                      </BarChart>
                    </ResponsiveContainer>
                  </div>
                </CardContent>
              </Card>

              {/* 项目排名 */}
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">项目执行率排名</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {allProjectsAnalysis
                      .sort((a, b) => b.executionRate - a.executionRate)
                      .map((proj, index) => (
                        <div key={proj.projectId} className="flex items-center gap-4">
                          <span className="w-8 h-8 rounded-full bg-gradient-to-br from-[#1d6a70] to-[#b1d658] flex items-center justify-center text-white text-sm font-bold">
                            {index + 1}
                          </span>
                          <div className="flex-1">
                            <div className="flex items-center justify-between mb-1">
                              <span className="font-medium">{proj.projectName}</span>
                              <span className="text-sm font-bold">{proj.executionRate.toFixed(1)}%</span>
                            </div>
                            <div className="h-2 bg-gray-100 rounded-full overflow-hidden">
                              <div 
                                className={`h-full rounded-full transition-all duration-1000 ${
                                  proj.executionRate > 100 ? 'bg-red-500' : 
                                  proj.executionRate > 80 ? 'bg-yellow-500' : 'bg-gradient-to-r from-[#1d6a70] to-[#b1d658]'
                                }`}
                                style={{ width: `${Math.min(proj.executionRate, 100)}%` }}
                              />
                            </div>
                            <p className="text-xs text-gray-400 mt-1">
                              {formatCurrency(proj.totalActual, true)} / {formatCurrency(proj.totalBudget, true)}
                            </p>
                          </div>
                        </div>
                      ))}
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </>
      )}
    </div>
  );
}
