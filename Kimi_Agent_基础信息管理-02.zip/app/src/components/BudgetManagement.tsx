import { useState, useEffect } from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Badge } from '@/components/ui/badge';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Plus, Search, Edit2, Trash2, Wallet, Calendar, Building2 } from 'lucide-react';
import { 
  getAnnualBudgets, 
  getMonthlyBudgets, 
  getDepartments, 
  getSubjects, 
  getProjects,
  saveAnnualBudget,
  saveMonthlyBudget,
  deleteAnnualBudget
} from '@/services/dataService';
import type { AnnualBudget, MonthlyBudget, Department, AccountSubject, Project } from '@/types';
import { formatCurrency } from '@/lib/utils';
import { toast } from 'sonner';

export function BudgetManagement() {
  const [activeTab, setActiveTab] = useState('annual');
  const [annualBudgets, setAnnualBudgets] = useState<AnnualBudget[]>([]);
  const [monthlyBudgets, setMonthlyBudgets] = useState<MonthlyBudget[]>([]);
  const [departments, setDepartments] = useState<Department[]>([]);
  const [subjects, setSubjects] = useState<AccountSubject[]>([]);
  const [projects, setProjects] = useState<Project[]>([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedYear, setSelectedYear] = useState(2026);
  const [selectedMonth, setSelectedMonth] = useState(3);
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [editingBudget, setEditingBudget] = useState<Partial<AnnualBudget & MonthlyBudget> | null>(null);

  useEffect(() => {
    loadData();
  }, [selectedYear, selectedMonth]);

  const loadData = () => {
    setDepartments(getDepartments());
    setSubjects(getSubjects());
    setProjects(getProjects());
    setAnnualBudgets(getAnnualBudgets(selectedYear));
    setMonthlyBudgets(getMonthlyBudgets(selectedYear, selectedMonth));
  };

  const handleSave = () => {
    if (!editingBudget?.departmentId || !editingBudget?.subjectId || !editingBudget?.amount) {
      toast.error('请填写完整信息');
      return;
    }

    if (activeTab === 'annual') {
      const budget: AnnualBudget = {
        id: editingBudget.id || `ab_${Date.now()}`,
        year: selectedYear,
        departmentId: editingBudget.departmentId,
        subjectId: editingBudget.subjectId,
        projectId: editingBudget.projectId,
        amount: Number(editingBudget.amount),
        createdAt: editingBudget.createdAt || new Date().toISOString(),
        updatedAt: new Date().toISOString()
      };
      saveAnnualBudget(budget);
    } else {
      const budget: MonthlyBudget = {
        id: editingBudget.id || `mb_${Date.now()}`,
        year: selectedYear,
        month: selectedMonth,
        departmentId: editingBudget.departmentId,
        subjectId: editingBudget.subjectId,
        projectId: editingBudget.projectId,
        amount: Number(editingBudget.amount),
        createdAt: editingBudget.createdAt || new Date().toISOString(),
        updatedAt: new Date().toISOString()
      };
      saveMonthlyBudget(budget);
    }

    toast.success('保存成功');
    setIsDialogOpen(false);
    setEditingBudget(null);
    loadData();
  };

  const handleDelete = (id: string) => {
    if (confirm('确定要删除这条预算吗？')) {
      deleteAnnualBudget(id);
      toast.success('删除成功');
      loadData();
    }
  };

  const filteredAnnualBudgets = annualBudgets.filter(budget => {
    const dept = departments.find(d => d.id === budget.departmentId);
    const subject = subjects.find(s => s.id === budget.subjectId);
    const project = projects.find(p => p.id === budget.projectId);
    return (
      dept?.name.includes(searchTerm) ||
      subject?.name.includes(searchTerm) ||
      project?.name.includes(searchTerm)
    );
  });

  const filteredMonthlyBudgets = monthlyBudgets.filter(budget => {
    const dept = departments.find(d => d.id === budget.departmentId);
    const subject = subjects.find(s => s.id === budget.subjectId);
    const project = projects.find(p => p.id === budget.projectId);
    return (
      dept?.name.includes(searchTerm) ||
      subject?.name.includes(searchTerm) ||
      project?.name.includes(searchTerm)
    );
  });

  const totalAnnualBudget = filteredAnnualBudgets.reduce((sum, b) => sum + b.amount, 0);
  const totalMonthlyBudget = filteredMonthlyBudgets.reduce((sum, b) => sum + b.amount, 0);

  return (
    <div className="p-6 space-y-6 animate-in fade-in duration-500">
      {/* 页面标题 */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-[#2c3e50]">预算管理</h1>
          <p className="text-sm text-gray-500 mt-1">年度预算编制与月度预算分配</p>
        </div>
        <Button 
          onClick={() => {
            setEditingBudget({});
            setIsDialogOpen(true);
          }}
          className="bg-gradient-to-r from-[#1d6a70] to-[#2a9d8f] hover:from-[#2a8a91] hover:to-[#1d6a70]"
        >
          <Plus className="h-4 w-4 mr-2" />
          新增预算
        </Button>
      </div>

      {/* 统计卡片 */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card className="bg-gradient-to-br from-[#1d6a70] to-[#2a9d8f] text-white">
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <Wallet className="h-8 w-8 opacity-80" />
              <div>
                <p className="text-sm opacity-80">年度总预算</p>
                <p className="text-2xl font-bold">{formatCurrency(totalAnnualBudget)}</p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card className="bg-gradient-to-br from-[#b1d658] to-[#7cb342] text-white">
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <Calendar className="h-8 w-8 opacity-80" />
              <div>
                <p className="text-sm opacity-80">本月预算</p>
                <p className="text-2xl font-bold">{formatCurrency(totalMonthlyBudget)}</p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card className="bg-gradient-to-br from-[#f4a261] to-[#e76f51] text-white">
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <Building2 className="h-8 w-8 opacity-80" />
              <div>
                <p className="text-sm opacity-80">预算条目数</p>
                <p className="text-2xl font-bold">{activeTab === 'annual' ? filteredAnnualBudgets.length : filteredMonthlyBudgets.length}</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* 主内容区 */}
      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList className="grid w-full max-w-md grid-cols-2">
          <TabsTrigger value="annual">年度预算</TabsTrigger>
          <TabsTrigger value="monthly">月度预算</TabsTrigger>
        </TabsList>

        <TabsContent value="annual" className="space-y-4">
          {/* 筛选栏 */}
          <div className="flex gap-4">
            <div className="relative flex-1 max-w-sm">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-gray-400" />
              <Input
                placeholder="搜索部门、科目或项目..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10"
              />
            </div>
            <Select value={String(selectedYear)} onValueChange={(v) => setSelectedYear(Number(v))}>
              <SelectTrigger className="w-32">
                <SelectValue placeholder="选择年份" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="2025">2025年</SelectItem>
                <SelectItem value="2026">2026年</SelectItem>
                <SelectItem value="2027">2027年</SelectItem>
              </SelectContent>
            </Select>
          </div>

          {/* 年度预算表格 */}
          <Card>
            <CardContent className="p-0">
              <ScrollArea className="h-[500px]">
                <Table>
                  <TableHeader className="sticky top-0 bg-white z-10">
                    <TableRow>
                      <TableHead>部门</TableHead>
                      <TableHead>预算科目</TableHead>
                      <TableHead>项目</TableHead>
                      <TableHead className="text-right">预算金额</TableHead>
                      <TableHead className="text-right">操作</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {filteredAnnualBudgets.map((budget) => {
                      const dept = departments.find(d => d.id === budget.departmentId);
                      const subject = subjects.find(s => s.id === budget.subjectId);
                      const project = projects.find(p => p.id === budget.projectId);
                      return (
                        <TableRow key={budget.id}>
                          <TableCell>
                            <Badge variant="outline">{dept?.name}</Badge>
                          </TableCell>
                          <TableCell>{subject?.name}</TableCell>
                          <TableCell>
                            <span className="text-sm text-gray-500">{project?.name}</span>
                          </TableCell>
                          <TableCell className="text-right font-medium">
                            {formatCurrency(budget.amount)}
                          </TableCell>
                          <TableCell className="text-right">
                            <Button
                              variant="ghost"
                              size="icon"
                              onClick={() => {
                                setEditingBudget(budget);
                                setIsDialogOpen(true);
                              }}
                            >
                              <Edit2 className="h-4 w-4" />
                            </Button>
                            <Button
                              variant="ghost"
                              size="icon"
                              onClick={() => handleDelete(budget.id)}
                            >
                              <Trash2 className="h-4 w-4 text-red-500" />
                            </Button>
                          </TableCell>
                        </TableRow>
                      );
                    })}
                  </TableBody>
                </Table>
              </ScrollArea>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="monthly" className="space-y-4">
          {/* 筛选栏 */}
          <div className="flex gap-4">
            <div className="relative flex-1 max-w-sm">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-gray-400" />
              <Input
                placeholder="搜索部门、科目或项目..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10"
              />
            </div>
            <Select value={String(selectedYear)} onValueChange={(v) => setSelectedYear(Number(v))}>
              <SelectTrigger className="w-32">
                <SelectValue placeholder="选择年份" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="2025">2025年</SelectItem>
                <SelectItem value="2026">2026年</SelectItem>
                <SelectItem value="2027">2027年</SelectItem>
              </SelectContent>
            </Select>
            <Select value={String(selectedMonth)} onValueChange={(v) => setSelectedMonth(Number(v))}>
              <SelectTrigger className="w-32">
                <SelectValue placeholder="选择月份" />
              </SelectTrigger>
              <SelectContent>
                {Array.from({ length: 12 }, (_, i) => (
                  <SelectItem key={i + 1} value={String(i + 1)}>{i + 1}月</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          {/* 月度预算表格 */}
          <Card>
            <CardContent className="p-0">
              <ScrollArea className="h-[500px]">
                <Table>
                  <TableHeader className="sticky top-0 bg-white z-10">
                    <TableRow>
                      <TableHead>部门</TableHead>
                      <TableHead>预算科目</TableHead>
                      <TableHead>项目</TableHead>
                      <TableHead className="text-right">月度预算</TableHead>
                      <TableHead className="text-right">操作</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {filteredMonthlyBudgets.map((budget) => {
                      const dept = departments.find(d => d.id === budget.departmentId);
                      const subject = subjects.find(s => s.id === budget.subjectId);
                      const project = projects.find(p => p.id === budget.projectId);
                      return (
                        <TableRow key={budget.id}>
                          <TableCell>
                            <Badge variant="outline">{dept?.name}</Badge>
                          </TableCell>
                          <TableCell>{subject?.name}</TableCell>
                          <TableCell>
                            <span className="text-sm text-gray-500">{project?.name}</span>
                          </TableCell>
                          <TableCell className="text-right font-medium">
                            {formatCurrency(budget.amount)}
                          </TableCell>
                          <TableCell className="text-right">
                            <Button
                              variant="ghost"
                              size="icon"
                              onClick={() => {
                                setEditingBudget(budget);
                                setIsDialogOpen(true);
                              }}
                            >
                              <Edit2 className="h-4 w-4" />
                            </Button>
                          </TableCell>
                        </TableRow>
                      );
                    })}
                  </TableBody>
                </Table>
              </ScrollArea>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      {/* 编辑对话框 */}
      <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
        <DialogContent className="max-w-lg">
          <DialogHeader>
            <DialogTitle>{editingBudget?.id ? '编辑预算' : '新增预算'}</DialogTitle>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label>年份</Label>
                <Input value={selectedYear} disabled />
              </div>
              {activeTab === 'monthly' && (
                <div className="space-y-2">
                  <Label>月份</Label>
                  <Input value={selectedMonth} disabled />
                </div>
              )}
            </div>
            <div className="space-y-2">
              <Label>部门</Label>
              <Select 
                value={editingBudget?.departmentId} 
                onValueChange={(v) => setEditingBudget({...editingBudget, departmentId: v})}
              >
                <SelectTrigger>
                  <SelectValue placeholder="选择部门" />
                </SelectTrigger>
                <SelectContent>
                  {departments.map(dept => (
                    <SelectItem key={dept.id} value={dept.id}>{dept.name}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label>预算科目</Label>
              <Select 
                value={editingBudget?.subjectId} 
                onValueChange={(v) => setEditingBudget({...editingBudget, subjectId: v})}
              >
                <SelectTrigger>
                  <SelectValue placeholder="选择科目" />
                </SelectTrigger>
                <SelectContent>
                  {subjects.map(subject => (
                    <SelectItem key={subject.id} value={subject.id}>{subject.name}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label>项目（可选）</Label>
              <Select 
                value={editingBudget?.projectId || 'none'} 
                onValueChange={(v) => setEditingBudget({...editingBudget, projectId: v === 'none' ? undefined : v})}
              >
                <SelectTrigger>
                  <SelectValue placeholder="选择项目" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="none">无项目</SelectItem>
                  {projects.map(project => (
                    <SelectItem key={project.id} value={project.id}>{project.name}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label>预算金额</Label>
              <Input
                type="number"
                placeholder="请输入预算金额"
                value={editingBudget?.amount || ''}
                onChange={(e) => setEditingBudget({...editingBudget, amount: Number(e.target.value)})}
              />
            </div>
          </div>
          <div className="flex justify-end gap-2">
            <Button variant="outline" onClick={() => setIsDialogOpen(false)}>取消</Button>
            <Button onClick={handleSave} className="bg-[#1d6a70] hover:bg-[#2a8a91]">保存</Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
