import { useEffect, useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
// Progress component imported for future use
import { Badge } from '@/components/ui/badge';
import { 
  TrendingUp, 
  Wallet, 
  CreditCard, 
  PiggyBank, 
  AlertTriangle,
  Bell,
  ArrowUpRight,
  ArrowDownRight,
  BarChart3
} from 'lucide-react';
import { 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
  LineChart,
  Line,
  Legend
} from 'recharts';
import { getDashboardData, getAlerts, markAlertAsRead } from '@/services/dataService';
import type { DashboardData, Alert, User } from '@/types';
import { formatCurrency } from '@/lib/utils';
import { Button } from '@/components/ui/button';
import { ScrollArea } from '@/components/ui/scroll-area';

interface DashboardProps {
  user: User;
}

const COLORS = ['#1d6a70', '#b1d658', '#f4a261', '#e76f51', '#2a9d8f', '#264653'];

export function Dashboard({ user }: DashboardProps) {
  const [data, setData] = useState<DashboardData | null>(null);
  const [alerts, setAlerts] = useState<Alert[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const loadData = () => {
      const dashboardData = getDashboardData(2026, 3);
      const alertData = getAlerts(user.role === 'manager' ? user.departmentId : undefined);
      setData(dashboardData);
      setAlerts(alertData.slice(0, 5));
      setLoading(false);
    };
    loadData();
  }, [user]);

  const handleMarkAlertRead = (alertId: string) => {
    markAlertAsRead(alertId);
    setAlerts(alerts.filter(a => a.id !== alertId));
  };

  if (loading || !data) {
    return (
      <div className="flex items-center justify-center h-full">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-[#1d6a70]"></div>
      </div>
    );
  }

  return (
    <div className="p-6 space-y-6 animate-in fade-in duration-500">
      {/* 页面标题 */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-[#2c3e50]">财务概览</h1>
          <p className="text-sm text-gray-500 mt-1">
            {new Date().toLocaleDateString('zh-CN', { year: 'numeric', month: 'long', day: 'numeric', weekday: 'long' })}
          </p>
        </div>
        <div className="flex items-center gap-2">
          <Badge variant="outline" className="bg-green-50 text-green-700 border-green-200">
            <span className="w-2 h-2 bg-green-500 rounded-full mr-1 animate-pulse"></span>
            实时数据
          </Badge>
        </div>
      </div>

      {/* 关键指标卡片 */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <MetricCard
          title="年度总预算"
          value={data.totalBudget}
          icon={Wallet}
          color="from-[#1d6a70] to-[#2a9d8f]"
          trend={+12.5}
        />
        <MetricCard
          title="已执行金额"
          value={data.totalActual}
          icon={CreditCard}
          color="from-[#b1d658] to-[#7cb342]"
          trend={+8.3}
        />
        <MetricCard
          title="剩余预算"
          value={data.totalRemaining}
          icon={PiggyBank}
          color="from-[#f4a261] to-[#e76f51]"
          trend={data.totalRemaining > 0 ? +5.2 : -3.1}
        />
        <MetricCard
          title="整体执行率"
          value={`${data.overallExecutionRate.toFixed(1)}%`}
          icon={TrendingUp}
          color="from-[#2a9d8f] to-[#1d6a70]"
          isPercentage
        />
      </div>

      {/* 图表区域 */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* 月度趋势图 */}
        <Card className="lg:col-span-2 hover:shadow-lg transition-shadow duration-300">
          <CardHeader>
            <CardTitle className="text-lg flex items-center gap-2">
              <TrendingUp className="h-5 w-5 text-[#1d6a70]" />
              预算执行趋势
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="h-80">
              <ResponsiveContainer width="100%" height="100%">
                <LineChart data={data.monthlyTrend}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#e0e0e0" />
                  <XAxis 
                    dataKey="period" 
                    tick={{ fontSize: 12 }}
                    stroke="#666"
                  />
                  <YAxis 
                    tick={{ fontSize: 12 }}
                    stroke="#666"
                    tickFormatter={(value) => formatCurrency(value, true)}
                  />
                  <Tooltip 
                    formatter={(value: number) => formatCurrency(value)}
                    contentStyle={{ 
                      backgroundColor: 'rgba(255, 255, 255, 0.95)',
                      border: '1px solid #e0e0e0',
                      borderRadius: '8px'
                    }}
                  />
                  <Legend />
                  <Line 
                    type="monotone" 
                    dataKey="budget" 
                    name="预算" 
                    stroke="#1d6a70" 
                    strokeWidth={2}
                    dot={{ fill: '#1d6a70', strokeWidth: 2 }}
                    activeDot={{ r: 6 }}
                  />
                  <Line 
                    type="monotone" 
                    dataKey="actual" 
                    name="实际" 
                    stroke="#b1d658" 
                    strokeWidth={2}
                    dot={{ fill: '#b1d658', strokeWidth: 2 }}
                    activeDot={{ r: 6 }}
                  />
                </LineChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>

        {/* 部门分布饼图 */}
        <Card className="hover:shadow-lg transition-shadow duration-300">
          <CardHeader>
            <CardTitle className="text-lg flex items-center gap-2">
              <Wallet className="h-5 w-5 text-[#1d6a70]" />
              部门预算分布
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="h-64">
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                    data={data.departmentStats}
                    cx="50%"
                    cy="50%"
                    innerRadius={60}
                    outerRadius={80}
                    paddingAngle={5}
                    dataKey="budget"
                    nameKey="departmentName"
                  >
                    {data.departmentStats.map((_entry, index) => (
                      <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                    ))}
                  </Pie>
                  <Tooltip formatter={(value: number) => formatCurrency(value)} />
                </PieChart>
              </ResponsiveContainer>
            </div>
            <div className="mt-4 space-y-2">
              {data.departmentStats.slice(0, 4).map((dept, index) => (
                <div key={dept.departmentId} className="flex items-center justify-between text-sm">
                  <div className="flex items-center gap-2">
                    <div 
                      className="w-3 h-3 rounded-full" 
                      style={{ backgroundColor: COLORS[index % COLORS.length] }}
                    />
                    <span className="text-gray-600 truncate max-w-[100px]">{dept.departmentName}</span>
                  </div>
                  <span className="font-medium">{formatCurrency(dept.budget, true)}</span>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* 部门执行统计和预警 */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* 部门执行统计 */}
        <Card className="hover:shadow-lg transition-shadow duration-300">
          <CardHeader>
            <CardTitle className="text-lg flex items-center gap-2">
              <BarChart3 className="h-5 w-5 text-[#1d6a70]" />
              部门预算执行情况
            </CardTitle>
          </CardHeader>
          <CardContent>
            <ScrollArea className="h-80">
              <div className="space-y-4">
                {data.departmentStats.map((dept) => (
                  <div key={dept.departmentId} className="space-y-2">
                    <div className="flex items-center justify-between">
                      <span className="text-sm font-medium text-gray-700">{dept.departmentName}</span>
                      <div className="flex items-center gap-4 text-sm">
                        <span className="text-gray-500">
                          {formatCurrency(dept.actual, true)} / {formatCurrency(dept.budget, true)}
                        </span>
                        <span className={`font-medium ${
                          dept.executionRate > 100 ? 'text-red-500' : 
                          dept.executionRate > 80 ? 'text-yellow-600' : 'text-green-600'
                        }`}>
                          {dept.executionRate.toFixed(1)}%
                        </span>
                      </div>
                    </div>
                    <div className="relative h-2 bg-gray-100 rounded-full overflow-hidden">
                      <div 
                        className={`absolute h-full rounded-full transition-all duration-1000 ${
                          dept.executionRate > 100 ? 'bg-red-500' : 
                          dept.executionRate > 80 ? 'bg-yellow-500' : 'bg-gradient-to-r from-[#1d6a70] to-[#b1d658]'
                        }`}
                        style={{ width: `${Math.min(dept.executionRate, 100)}%` }}
                      />
                    </div>
                  </div>
                ))}
              </div>
            </ScrollArea>
          </CardContent>
        </Card>

        {/* 预警信息 */}
        <Card className="hover:shadow-lg transition-shadow duration-300">
          <CardHeader>
            <CardTitle className="text-lg flex items-center gap-2">
              <Bell className="h-5 w-5 text-[#1d6a70]" />
              预警提醒
              {alerts.filter(a => !a.isRead).length > 0 && (
                <Badge className="bg-red-500 text-white">
                  {alerts.filter(a => !a.isRead).length}
                </Badge>
              )}
            </CardTitle>
          </CardHeader>
          <CardContent>
            <ScrollArea className="h-80">
              <div className="space-y-3">
                {alerts.length === 0 ? (
                  <div className="text-center py-8 text-gray-400">
                    <Bell className="h-12 w-12 mx-auto mb-2 opacity-50" />
                    <p>暂无预警信息</p>
                  </div>
                ) : (
                  alerts.map((alert) => (
                    <div 
                      key={alert.id} 
                      className={`p-4 rounded-lg border-l-4 transition-all duration-300 hover:shadow-md ${
                        alert.level === 'critical' ? 'bg-red-50 border-red-500' :
                        alert.level === 'warning' ? 'bg-yellow-50 border-yellow-500' :
                        'bg-blue-50 border-blue-500'
                      }`}
                    >
                      <div className="flex items-start justify-between">
                        <div className="flex-1">
                          <div className="flex items-center gap-2 mb-1">
                            <AlertTriangle className={`h-4 w-4 ${
                              alert.level === 'critical' ? 'text-red-500' :
                              alert.level === 'warning' ? 'text-yellow-500' :
                              'text-blue-500'
                            }`} />
                            <span className="font-medium text-sm">{alert.title}</span>
                          </div>
                          <p className="text-xs text-gray-600">{alert.message}</p>
                          <p className="text-xs text-gray-400 mt-1">
                            {new Date(alert.createdAt).toLocaleString('zh-CN')}
                          </p>
                        </div>
                        {!alert.isRead && (
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => handleMarkAlertRead(alert.id)}
                            className="text-xs"
                          >
                            标记已读
                          </Button>
                        )}
                      </div>
                    </div>
                  ))
                )}
              </div>
            </ScrollArea>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}

// 指标卡片组件
interface MetricCardProps {
  title: string;
  value: number | string;
  icon: React.ElementType;
  color: string;
  trend?: number;
  isPercentage?: boolean;
}

function MetricCard({ title, value, icon: Icon, color, trend, isPercentage }: MetricCardProps) {
  const displayValue = typeof value === 'number' && !isPercentage 
    ? formatCurrency(value) 
    : value;

  return (
    <Card className="relative overflow-hidden group hover:shadow-xl transition-all duration-300 hover:-translate-y-1">
      <div className={`absolute top-0 right-0 w-32 h-32 bg-gradient-to-br ${color} opacity-10 rounded-full -translate-y-1/2 translate-x-1/2 group-hover:scale-150 transition-transform duration-500`} />
      <CardContent className="p-6">
        <div className="flex items-start justify-between">
          <div>
            <p className="text-sm text-gray-500 mb-1">{title}</p>
            <p className="text-2xl font-bold text-[#2c3e50]">{displayValue}</p>
            {trend !== undefined && (
              <div className={`flex items-center gap-1 mt-2 text-sm ${
                trend > 0 ? 'text-green-600' : 'text-red-600'
              }`}>
                {trend > 0 ? (
                  <ArrowUpRight className="h-4 w-4" />
                ) : (
                  <ArrowDownRight className="h-4 w-4" />
                )}
                <span>{Math.abs(trend)}%</span>
                <span className="text-gray-400 text-xs">vs 上月</span>
              </div>
            )}
          </div>
          <div className={`p-3 rounded-lg bg-gradient-to-br ${color} shadow-lg`}>
            <Icon className="h-6 w-6 text-white" />
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
