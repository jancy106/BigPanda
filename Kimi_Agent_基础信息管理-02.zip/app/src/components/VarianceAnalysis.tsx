import { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Badge } from '@/components/ui/badge';
import { ScrollArea } from '@/components/ui/scroll-area';
import { 
  BarChart3, 
  AlertTriangle, 
  TrendingUp, 
  TrendingDown, 
  Minus,
  Download,
  Filter
} from 'lucide-react';
import { 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer
} from 'recharts';
import { calculateBudgetExecution, getDepartments, getSubjects, getProjects } from '@/services/dataService';
import type { BudgetExecution, User } from '@/types';
import { formatCurrency } from '@/lib/utils';
import { toast } from 'sonner';
import * as XLSX from 'xlsx';

interface VarianceAnalysisProps {
  user: User;
}

export function VarianceAnalysis({ user }: VarianceAnalysisProps) {
  const [executions, setExecutions] = useState<BudgetExecution[]>([]);
  const [filteredExecutions, setFilteredExecutions] = useState<BudgetExecution[]>([]);
  const [departments, setDepartments] = useState<{id: string, name: string}[]>([]);
  const [, setSubjects] = useState<{id: string, name: string}[]>([]);
  const [projects, setProjects] = useState<{id: string, name: string}[]>([]);
  const [selectedYear, setSelectedYear] = useState(2026);
  const [selectedMonth, setSelectedMonth] = useState(3);
  const [filterDepartment, setFilterDepartment] = useState<string>('all');
  const [filterProject, setFilterProject] = useState<string>('all');
  const [filterVariance, setFilterVariance] = useState<string>('all');

  useEffect(() => {
    loadData();
  }, [selectedYear, selectedMonth, user]);

  useEffect(() => {
    applyFilters();
  }, [executions, filterDepartment, filterProject, filterVariance]);

  const loadData = () => {
    setDepartments(getDepartments());
    setSubjects(getSubjects());
    setProjects(getProjects());
    
    const data = calculateBudgetExecution(selectedYear, selectedMonth);
    const departmentId = user.role === 'manager' ? user.departmentId : undefined;
    setExecutions(departmentId ? data.filter(e => e.departmentId === departmentId) : data);
  };

  const applyFilters = () => {
    let filtered = [...executions];
    
    if (filterDepartment !== 'all') {
      filtered = filtered.filter(e => e.departmentId === filterDepartment);
    }
    if (filterProject !== 'all') {
      filtered = filtered.filter(e => e.projectId === filterProject);
    }
    if (filterVariance !== 'all') {
      if (filterVariance === 'overspend') {
        filtered = filtered.filter(e => e.variance > 0);
      } else if (filterVariance === 'savings') {
        filtered = filtered.filter(e => e.variance < 0);
      } else if (filterVariance === 'ontrack') {
        filtered = filtered.filter(e => Math.abs(e.varianceRate) <= 10);
      }
    }
    
    setFilteredExecutions(filtered);
  };

  const handleExport = () => {
    const data = filteredExecutions.map(e => ({
      '部门': e.departmentName,
      '科目': e.subjectName,
      '项目': e.projectName,
      '预算': e.monthlyBudget || e.annualBudget,
      '实际': e.actualExpense,
      '差异': e.variance,
      '差异率': `${e.varianceRate.toFixed(2)}%`,
      '执行率': `${e.executionRate.toFixed(2)}%`,
      '状态': e.variance > 0 ? '超支' : e.variance < 0 ? '结余' : '正常'
    }));

    const ws = XLSX.utils.json_to_sheet(data);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, '差异分析');
    XLSX.writeFile(wb, `差异分析_${selectedYear}_${selectedMonth}.xlsx`);
    toast.success('导出成功');
  };

  const getVarianceBadge = (variance: number, varianceRate: number) => {
    if (variance > 0) {
      return (
        <Badge variant="destructive" className="flex items-center gap-1">
          <TrendingUp className="h-3 w-3" />
          超支 {varianceRate.toFixed(1)}%
        </Badge>
      );
    } else if (variance < 0) {
      return (
        <Badge variant="default" className="bg-green-500 flex items-center gap-1">
          <TrendingDown className="h-3 w-3" />
          结余 {Math.abs(varianceRate).toFixed(1)}%
        </Badge>
      );
    }
    return (
      <Badge variant="secondary" className="flex items-center gap-1">
        <Minus className="h-3 w-3" />
        正常
      </Badge>
    );
  };

  const chartData = filteredExecutions
    .filter(e => Math.abs(e.variance) > 0)
    .slice(0, 20)
    .map(e => ({
      name: `${e.departmentName}-${e.subjectName}`.substring(0, 15),
      budget: e.monthlyBudget || e.annualBudget,
      actual: e.actualExpense,
      variance: e.variance
    }));

  const totalBudget = filteredExecutions.reduce((sum, e) => sum + (e.monthlyBudget || e.annualBudget), 0);
  const totalActual = filteredExecutions.reduce((sum, e) => sum + e.actualExpense, 0);
  const totalVariance = totalActual - totalBudget;
  const overallExecutionRate = totalBudget > 0 ? (totalActual / totalBudget) * 100 : 0;

  const overspendCount = filteredExecutions.filter(e => e.variance > 0).length;
  const savingsCount = filteredExecutions.filter(e => e.variance < 0).length;

  return (
    <div className="p-6 space-y-6 animate-in fade-in duration-500">
      {/* 页面标题 */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-[#2c3e50]">差异分析</h1>
          <p className="text-sm text-gray-500 mt-1">预算与实际支出对比分析</p>
        </div>
        <Button variant="outline" onClick={handleExport}>
          <Download className="h-4 w-4 mr-2" />
          导出报告
        </Button>
      </div>

      {/* 统计卡片 */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card className="bg-gradient-to-br from-[#1d6a70] to-[#2a9d8f] text-white">
          <CardContent className="p-4">
            <div>
              <p className="text-sm opacity-80">总预算</p>
              <p className="text-2xl font-bold">{formatCurrency(totalBudget)}</p>
            </div>
          </CardContent>
        </Card>
        <Card className="bg-gradient-to-br from-[#b1d658] to-[#7cb342] text-white">
          <CardContent className="p-4">
            <div>
              <p className="text-sm opacity-80">实际支出</p>
              <p className="text-2xl font-bold">{formatCurrency(totalActual)}</p>
            </div>
          </CardContent>
        </Card>
        <Card className={`${totalVariance > 0 ? 'bg-gradient-to-br from-red-500 to-red-600' : 'bg-gradient-to-br from-green-500 to-green-600'} text-white`}>
          <CardContent className="p-4">
            <div>
              <p className="text-sm opacity-80">总差异</p>
              <p className="text-2xl font-bold">{totalVariance > 0 ? '+' : ''}{formatCurrency(totalVariance)}</p>
            </div>
          </CardContent>
        </Card>
        <Card className="bg-gradient-to-br from-[#f4a261] to-[#e76f51] text-white">
          <CardContent className="p-4">
            <div>
              <p className="text-sm opacity-80">整体执行率</p>
              <p className="text-2xl font-bold">{overallExecutionRate.toFixed(1)}%</p>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* 预警卡片 */}
      {(overspendCount > 0 || savingsCount > 0) && (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {overspendCount > 0 && (
            <Card className="border-red-200 bg-red-50">
              <CardContent className="p-4 flex items-center gap-3">
                <AlertTriangle className="h-8 w-8 text-red-500" />
                <div>
                  <p className="font-medium text-red-800">超支预警</p>
                  <p className="text-sm text-red-600">有 {overspendCount} 项预算超支，请及时关注</p>
                </div>
              </CardContent>
            </Card>
          )}
          {savingsCount > 0 && (
            <Card className="border-green-200 bg-green-50">
              <CardContent className="p-4 flex items-center gap-3">
                <TrendingDown className="h-8 w-8 text-green-500" />
                <div>
                  <p className="font-medium text-green-800">结余提醒</p>
                  <p className="text-sm text-green-600">有 {savingsCount} 项预算有结余</p>
                </div>
              </CardContent>
            </Card>
          )}
        </div>
      )}

      {/* 筛选栏 */}
      <div className="flex flex-wrap gap-4">
        <Select value={String(selectedYear)} onValueChange={(v) => setSelectedYear(Number(v))}>
          <SelectTrigger className="w-32">
            <SelectValue placeholder="选择年份" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="2025">2025年</SelectItem>
            <SelectItem value="2026">2026年</SelectItem>
            <SelectItem value="2027">2027年</SelectItem>
          </SelectContent>
        </Select>
        <Select value={String(selectedMonth)} onValueChange={(v) => setSelectedMonth(Number(v))}>
          <SelectTrigger className="w-32">
            <SelectValue placeholder="选择月份" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="0">全年</SelectItem>
            {Array.from({ length: 12 }, (_, i) => (
              <SelectItem key={i + 1} value={String(i + 1)}>{i + 1}月</SelectItem>
            ))}
          </SelectContent>
        </Select>
        <Select value={filterDepartment} onValueChange={setFilterDepartment}>
          <SelectTrigger className="w-40">
            <Filter className="h-4 w-4 mr-2" />
            <SelectValue placeholder="筛选部门" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">全部部门</SelectItem>
            {departments.map(dept => (
              <SelectItem key={dept.id} value={dept.id}>{dept.name}</SelectItem>
            ))}
          </SelectContent>
        </Select>
        <Select value={filterProject} onValueChange={setFilterProject}>
          <SelectTrigger className="w-40">
            <Filter className="h-4 w-4 mr-2" />
            <SelectValue placeholder="筛选项目" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">全部项目</SelectItem>
            {projects.map(proj => (
              <SelectItem key={proj.id} value={proj.id}>{proj.name}</SelectItem>
            ))}
          </SelectContent>
        </Select>
        <Select value={filterVariance} onValueChange={setFilterVariance}>
          <SelectTrigger className="w-40">
            <Filter className="h-4 w-4 mr-2" />
            <SelectValue placeholder="差异类型" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">全部类型</SelectItem>
            <SelectItem value="overspend">超支</SelectItem>
            <SelectItem value="savings">结余</SelectItem>
            <SelectItem value="ontrack">正常</SelectItem>
          </SelectContent>
        </Select>
      </div>

      {/* 图表 */}
      <Card>
        <CardHeader>
          <CardTitle className="text-lg flex items-center gap-2">
            <BarChart3 className="h-5 w-5 text-[#1d6a70]" />
            预算 vs 实际对比（前20项）
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="h-80">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={chartData}>
                <CartesianGrid strokeDasharray="3 3" stroke="#e0e0e0" />
                <XAxis dataKey="name" tick={{ fontSize: 10 }} angle={-45} textAnchor="end" height={80} />
                <YAxis tickFormatter={(value) => formatCurrency(value, true)} />
                <Tooltip formatter={(value: number) => formatCurrency(value)} />
                <Bar dataKey="budget" name="预算" fill="#1d6a70" />
                <Bar dataKey="actual" name="实际" fill="#b1d658" />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </CardContent>
      </Card>

      {/* 详细表格 */}
      <Card>
        <CardHeader>
          <CardTitle className="text-lg flex items-center gap-2">
            <BarChart3 className="h-5 w-5 text-[#1d6a70]" />
            差异明细
          </CardTitle>
        </CardHeader>
        <CardContent className="p-0">
          <ScrollArea className="h-[500px]">
            <Table>
              <TableHeader className="sticky top-0 bg-white z-10">
                <TableRow>
                  <TableHead>部门</TableHead>
                  <TableHead>科目</TableHead>
                  <TableHead>项目</TableHead>
                  <TableHead className="text-right">预算</TableHead>
                  <TableHead className="text-right">实际</TableHead>
                  <TableHead className="text-right">差异</TableHead>
                  <TableHead>状态</TableHead>
                  <TableHead className="text-right">执行率</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredExecutions.map((execution) => (
                  <TableRow key={`${execution.departmentId}-${execution.subjectId}-${execution.projectId}`}>
                    <TableCell>
                      <Badge variant="outline">{execution.departmentName}</Badge>
                    </TableCell>
                    <TableCell>{execution.subjectName}</TableCell>
                    <TableCell>
                      <span className="text-sm text-gray-500">{execution.projectName}</span>
                    </TableCell>
                    <TableCell className="text-right">
                      {formatCurrency(execution.monthlyBudget || execution.annualBudget, true)}
                    </TableCell>
                    <TableCell className="text-right font-medium">
                      {formatCurrency(execution.actualExpense, true)}
                    </TableCell>
                    <TableCell className={`text-right font-medium ${
                      execution.variance > 0 ? 'text-red-600' : execution.variance < 0 ? 'text-green-600' : ''
                    }`}>
                      {execution.variance > 0 ? '+' : ''}{formatCurrency(execution.variance, true)}
                    </TableCell>
                    <TableCell>{getVarianceBadge(execution.variance, execution.varianceRate)}</TableCell>
                    <TableCell className="text-right">
                      <span className={`font-medium ${
                        execution.executionRate > 100 ? 'text-red-600' : 
                        execution.executionRate > 80 ? 'text-yellow-600' : 'text-green-600'
                      }`}>
                        {execution.executionRate.toFixed(1)}%
                      </span>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </ScrollArea>
        </CardContent>
      </Card>
    </div>
  );
}
