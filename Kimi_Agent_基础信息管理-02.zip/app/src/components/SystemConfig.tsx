import { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Badge } from '@/components/ui/badge';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { 
  Settings, 
  Plus,
  Edit2,
  Trash2,
  Save
} from 'lucide-react';
import { 
  getDepartments, 
  getSubjects, 
  getProjects,
  getUsers,
  getSystemConfig,
  saveDepartment,
  saveSubject,
  saveProject,
  saveUser,
  saveSystemConfig,
  deleteDepartment,
  deleteSubject,
  deleteProject,
  deleteUser,
  initializeDefaultData
} from '@/services/dataService';
import type { Department, AccountSubject, Project, User as UserType, SystemConfig } from '@/types';
import { toast } from 'sonner';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';

export function SystemConfigModule() {
  const [activeTab, setActiveTab] = useState('general');
  const [departments, setDepartments] = useState<Department[]>([]);
  const [subjects, setSubjects] = useState<AccountSubject[]>([]);
  const [projects, setProjects] = useState<Project[]>([]);
  const [users, setUsers] = useState<UserType[]>([]);
  const [config, setConfig] = useState<SystemConfig>({
    companyName: '',
    fiscalYear: 2026,
    paymentPlanDeadline: 25,
    currency: 'CNY',
    budgetAlertThreshold: 90
  });

  // 对话框状态
  const [deptDialogOpen, setDeptDialogOpen] = useState(false);
  const [subjectDialogOpen, setSubjectDialogOpen] = useState(false);
  const [projectDialogOpen, setProjectDialogOpen] = useState(false);
  const [userDialogOpen, setUserDialogOpen] = useState(false);
  
  // 编辑状态
  const [editingDept, setEditingDept] = useState<Partial<Department>>({});
  const [editingSubject, setEditingSubject] = useState<Partial<AccountSubject>>({});
  const [editingProject, setEditingProject] = useState<Partial<Project>>({});
  const [editingUser, setEditingUser] = useState<Partial<UserType>>({});

  useEffect(() => {
    loadData();
  }, []);

  const loadData = () => {
    setDepartments(getDepartments());
    setSubjects(getSubjects());
    setProjects(getProjects());
    setUsers(getUsers());
    setConfig(getSystemConfig());
  };

  const handleSaveConfig = () => {
    saveSystemConfig(config);
    toast.success('系统配置保存成功');
  };

  const handleSaveDepartment = () => {
    if (!editingDept.name || !editingDept.code) {
      toast.error('请填写完整信息');
      return;
    }
    const dept: Department = {
      id: editingDept.id || `dept_${Date.now()}`,
      name: editingDept.name,
      code: editingDept.code,
      managerId: editingDept.managerId,
      description: editingDept.description
    };
    saveDepartment(dept);
    toast.success('部门保存成功');
    setDeptDialogOpen(false);
    setEditingDept({});
    loadData();
  };

  const handleSaveSubject = () => {
    if (!editingSubject.name || !editingSubject.code) {
      toast.error('请填写完整信息');
      return;
    }
    const subject: AccountSubject = {
      id: editingSubject.id || `sub_${Date.now()}`,
      name: editingSubject.name,
      code: editingSubject.code,
      category: editingSubject.category || 'expense',
      parentId: editingSubject.parentId,
      description: editingSubject.description
    };
    saveSubject(subject);
    toast.success('科目保存成功');
    setSubjectDialogOpen(false);
    setEditingSubject({});
    loadData();
  };

  const handleSaveProject = () => {
    if (!editingProject.name || !editingProject.code) {
      toast.error('请填写完整信息');
      return;
    }
    const project: Project = {
      id: editingProject.id || `proj_${Date.now()}`,
      name: editingProject.name,
      code: editingProject.code,
      status: editingProject.status || 'ongoing',
      startDate: editingProject.startDate || new Date().toISOString().split('T')[0],
      endDate: editingProject.endDate,
      description: editingProject.description
    };
    saveProject(project);
    toast.success('项目保存成功');
    setProjectDialogOpen(false);
    setEditingProject({});
    loadData();
  };

  const handleSaveUser = () => {
    if (!editingUser.name || !editingUser.email || !editingUser.role) {
      toast.error('请填写完整信息');
      return;
    }
    const user: UserType = {
      id: editingUser.id || `user_${Date.now()}`,
      name: editingUser.name,
      email: editingUser.email,
      role: editingUser.role as 'admin' | 'manager' | 'boss',
      departmentId: editingUser.departmentId,
      avatar: editingUser.avatar
    };
    saveUser(user);
    toast.success('用户保存成功');
    setUserDialogOpen(false);
    setEditingUser({});
    loadData();
  };

  const handleResetData = () => {
    if (confirm('确定要重置所有数据吗？此操作不可恢复！')) {
      localStorage.clear();
      initializeDefaultData();
      loadData();
      toast.success('数据已重置');
    }
  };

  const getCategoryName = (category: string) => {
    switch (category) {
      case 'expense': return '费用';
      case 'capital': return '资本';
      case 'operating': return '运营';
      default: return category;
    }
  };

  const getRoleName = (role: string) => {
    switch (role) {
      case 'admin': return '管理员';
      case 'manager': return '部门经理';
      case 'boss': return '总经理';
      default: return role;
    }
  };

  const getStatusName = (status: string) => {
    switch (status) {
      case 'planning': return '规划中';
      case 'ongoing': return '进行中';
      case 'completed': return '已完成';
      case 'suspended': return '已暂停';
      default: return status;
    }
  };

  return (
    <div className="p-6 space-y-6 animate-in fade-in duration-500">
      {/* 页面标题 */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-[#2c3e50]">系统配置</h1>
          <p className="text-sm text-gray-500 mt-1">管理系统基础数据与配置</p>
        </div>
        <Button variant="destructive" onClick={handleResetData}>
          重置数据
        </Button>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList className="grid w-full max-w-lg grid-cols-5">
          <TabsTrigger value="general">通用</TabsTrigger>
          <TabsTrigger value="departments">部门</TabsTrigger>
          <TabsTrigger value="subjects">科目</TabsTrigger>
          <TabsTrigger value="projects">项目</TabsTrigger>
          <TabsTrigger value="users">用户</TabsTrigger>
        </TabsList>

        <TabsContent value="general" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="text-lg flex items-center gap-2">
                <Settings className="h-5 w-5 text-[#1d6a70]" />
                系统通用配置
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label>公司名称</Label>
                  <Input
                    value={config.companyName}
                    onChange={(e) => setConfig({...config, companyName: e.target.value})}
                  />
                </div>
                <div className="space-y-2">
                  <Label>财年</Label>
                  <Input
                    type="number"
                    value={config.fiscalYear}
                    onChange={(e) => setConfig({...config, fiscalYear: Number(e.target.value)})}
                  />
                </div>
                <div className="space-y-2">
                  <Label>付款计划截止日（每月）</Label>
                  <Input
                    type="number"
                    min={1}
                    max={31}
                    value={config.paymentPlanDeadline}
                    onChange={(e) => setConfig({...config, paymentPlanDeadline: Number(e.target.value)})}
                  />
                </div>
                <div className="space-y-2">
                  <Label>预算预警阈值 (%)</Label>
                  <Input
                    type="number"
                    min={50}
                    max={100}
                    value={config.budgetAlertThreshold}
                    onChange={(e) => setConfig({...config, budgetAlertThreshold: Number(e.target.value)})}
                  />
                </div>
              </div>
              <Button onClick={handleSaveConfig} className="bg-[#1d6a70] hover:bg-[#2a8a91]">
                <Save className="h-4 w-4 mr-2" />
                保存配置
              </Button>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="departments" className="space-y-6">
          <div className="flex justify-end">
            <Button onClick={() => { setEditingDept({}); setDeptDialogOpen(true); }}>
              <Plus className="h-4 w-4 mr-2" />
              新增部门
            </Button>
          </div>
          <Card>
            <CardContent className="p-0">
              <ScrollArea className="h-[500px]">
                <Table>
                  <TableHeader className="sticky top-0 bg-white z-10">
                    <TableRow>
                      <TableHead>部门代码</TableHead>
                      <TableHead>部门名称</TableHead>
                      <TableHead>描述</TableHead>
                      <TableHead className="text-right">操作</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {departments.map((dept) => (
                      <TableRow key={dept.id}>
                        <TableCell><Badge variant="outline">{dept.code}</Badge></TableCell>
                        <TableCell className="font-medium">{dept.name}</TableCell>
                        <TableCell className="text-gray-500">{dept.description}</TableCell>
                        <TableCell className="text-right">
                          <Button
                            variant="ghost"
                            size="icon"
                            onClick={() => { setEditingDept(dept); setDeptDialogOpen(true); }}
                          >
                            <Edit2 className="h-4 w-4" />
                          </Button>
                          <Button
                            variant="ghost"
                            size="icon"
                            onClick={() => { deleteDepartment(dept.id); loadData(); }}
                          >
                            <Trash2 className="h-4 w-4 text-red-500" />
                          </Button>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </ScrollArea>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="subjects" className="space-y-6">
          <div className="flex justify-end">
            <Button onClick={() => { setEditingSubject({}); setSubjectDialogOpen(true); }}>
              <Plus className="h-4 w-4 mr-2" />
              新增科目
            </Button>
          </div>
          <Card>
            <CardContent className="p-0">
              <ScrollArea className="h-[500px]">
                <Table>
                  <TableHeader className="sticky top-0 bg-white z-10">
                    <TableRow>
                      <TableHead>科目代码</TableHead>
                      <TableHead>科目名称</TableHead>
                      <TableHead>类别</TableHead>
                      <TableHead className="text-right">操作</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {subjects.map((subject) => (
                      <TableRow key={subject.id}>
                        <TableCell><Badge variant="outline">{subject.code}</Badge></TableCell>
                        <TableCell className="font-medium">{subject.name}</TableCell>
                        <TableCell>{getCategoryName(subject.category)}</TableCell>
                        <TableCell className="text-right">
                          <Button
                            variant="ghost"
                            size="icon"
                            onClick={() => { setEditingSubject(subject); setSubjectDialogOpen(true); }}
                          >
                            <Edit2 className="h-4 w-4" />
                          </Button>
                          <Button
                            variant="ghost"
                            size="icon"
                            onClick={() => { deleteSubject(subject.id); loadData(); }}
                          >
                            <Trash2 className="h-4 w-4 text-red-500" />
                          </Button>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </ScrollArea>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="projects" className="space-y-6">
          <div className="flex justify-end">
            <Button onClick={() => { setEditingProject({}); setProjectDialogOpen(true); }}>
              <Plus className="h-4 w-4 mr-2" />
              新增项目
            </Button>
          </div>
          <Card>
            <CardContent className="p-0">
              <ScrollArea className="h-[500px]">
                <Table>
                  <TableHeader className="sticky top-0 bg-white z-10">
                    <TableRow>
                      <TableHead>项目代码</TableHead>
                      <TableHead>项目名称</TableHead>
                      <TableHead>状态</TableHead>
                      <TableHead className="text-right">操作</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {projects.map((project) => (
                      <TableRow key={project.id}>
                        <TableCell><Badge variant="outline">{project.code}</Badge></TableCell>
                        <TableCell className="font-medium">{project.name}</TableCell>
                        <TableCell>{getStatusName(project.status)}</TableCell>
                        <TableCell className="text-right">
                          <Button
                            variant="ghost"
                            size="icon"
                            onClick={() => { setEditingProject(project); setProjectDialogOpen(true); }}
                          >
                            <Edit2 className="h-4 w-4" />
                          </Button>
                          <Button
                            variant="ghost"
                            size="icon"
                            onClick={() => { deleteProject(project.id); loadData(); }}
                          >
                            <Trash2 className="h-4 w-4 text-red-500" />
                          </Button>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </ScrollArea>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="users" className="space-y-6">
          <div className="flex justify-end">
            <Button onClick={() => { setEditingUser({}); setUserDialogOpen(true); }}>
              <Plus className="h-4 w-4 mr-2" />
              新增用户
            </Button>
          </div>
          <Card>
            <CardContent className="p-0">
              <ScrollArea className="h-[500px]">
                <Table>
                  <TableHeader className="sticky top-0 bg-white z-10">
                    <TableRow>
                      <TableHead>姓名</TableHead>
                      <TableHead>邮箱</TableHead>
                      <TableHead>角色</TableHead>
                      <TableHead>部门</TableHead>
                      <TableHead className="text-right">操作</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {users.map((user) => (
                      <TableRow key={user.id}>
                        <TableCell className="font-medium">{user.name}</TableCell>
                        <TableCell>{user.email}</TableCell>
                        <TableCell>{getRoleName(user.role)}</TableCell>
                        <TableCell>
                          {user.departmentId && (
                            <Badge variant="outline">
                              {departments.find(d => d.id === user.departmentId)?.name}
                            </Badge>
                          )}
                        </TableCell>
                        <TableCell className="text-right">
                          <Button
                            variant="ghost"
                            size="icon"
                            onClick={() => { setEditingUser(user); setUserDialogOpen(true); }}
                          >
                            <Edit2 className="h-4 w-4" />
                          </Button>
                          <Button
                            variant="ghost"
                            size="icon"
                            onClick={() => { deleteUser(user.id); loadData(); }}
                          >
                            <Trash2 className="h-4 w-4 text-red-500" />
                          </Button>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </ScrollArea>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      {/* 部门编辑对话框 */}
      <Dialog open={deptDialogOpen} onOpenChange={setDeptDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>{editingDept.id ? '编辑部门' : '新增部门'}</DialogTitle>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <Label>部门代码</Label>
              <Input value={editingDept.code || ''} onChange={(e) => setEditingDept({...editingDept, code: e.target.value})} />
            </div>
            <div className="space-y-2">
              <Label>部门名称</Label>
              <Input value={editingDept.name || ''} onChange={(e) => setEditingDept({...editingDept, name: e.target.value})} />
            </div>
            <div className="space-y-2">
              <Label>描述</Label>
              <Input value={editingDept.description || ''} onChange={(e) => setEditingDept({...editingDept, description: e.target.value})} />
            </div>
          </div>
          <div className="flex justify-end gap-2">
            <Button variant="outline" onClick={() => setDeptDialogOpen(false)}>取消</Button>
            <Button onClick={handleSaveDepartment}>保存</Button>
          </div>
        </DialogContent>
      </Dialog>

      {/* 科目编辑对话框 */}
      <Dialog open={subjectDialogOpen} onOpenChange={setSubjectDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>{editingSubject.id ? '编辑科目' : '新增科目'}</DialogTitle>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <Label>科目代码</Label>
              <Input value={editingSubject.code || ''} onChange={(e) => setEditingSubject({...editingSubject, code: e.target.value})} />
            </div>
            <div className="space-y-2">
              <Label>科目名称</Label>
              <Input value={editingSubject.name || ''} onChange={(e) => setEditingSubject({...editingSubject, name: e.target.value})} />
            </div>
            <div className="space-y-2">
              <Label>类别</Label>
              <Select 
                value={editingSubject.category} 
                onValueChange={(v: any) => setEditingSubject({...editingSubject, category: v})}
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="expense">费用</SelectItem>
                  <SelectItem value="capital">资本</SelectItem>
                  <SelectItem value="operating">运营</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
          <div className="flex justify-end gap-2">
            <Button variant="outline" onClick={() => setSubjectDialogOpen(false)}>取消</Button>
            <Button onClick={handleSaveSubject}>保存</Button>
          </div>
        </DialogContent>
      </Dialog>

      {/* 项目编辑对话框 */}
      <Dialog open={projectDialogOpen} onOpenChange={setProjectDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>{editingProject.id ? '编辑项目' : '新增项目'}</DialogTitle>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <Label>项目代码</Label>
              <Input value={editingProject.code || ''} onChange={(e) => setEditingProject({...editingProject, code: e.target.value})} />
            </div>
            <div className="space-y-2">
              <Label>项目名称</Label>
              <Input value={editingProject.name || ''} onChange={(e) => setEditingProject({...editingProject, name: e.target.value})} />
            </div>
            <div className="space-y-2">
              <Label>状态</Label>
              <Select 
                value={editingProject.status} 
                onValueChange={(v: any) => setEditingProject({...editingProject, status: v})}
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="planning">规划中</SelectItem>
                  <SelectItem value="ongoing">进行中</SelectItem>
                  <SelectItem value="completed">已完成</SelectItem>
                  <SelectItem value="suspended">已暂停</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label>开始日期</Label>
              <Input 
                type="date" 
                value={editingProject.startDate || ''} 
                onChange={(e) => setEditingProject({...editingProject, startDate: e.target.value})} 
              />
            </div>
          </div>
          <div className="flex justify-end gap-2">
            <Button variant="outline" onClick={() => setProjectDialogOpen(false)}>取消</Button>
            <Button onClick={handleSaveProject}>保存</Button>
          </div>
        </DialogContent>
      </Dialog>

      {/* 用户编辑对话框 */}
      <Dialog open={userDialogOpen} onOpenChange={setUserDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>{editingUser.id ? '编辑用户' : '新增用户'}</DialogTitle>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <Label>姓名</Label>
              <Input value={editingUser.name || ''} onChange={(e) => setEditingUser({...editingUser, name: e.target.value})} />
            </div>
            <div className="space-y-2">
              <Label>邮箱</Label>
              <Input value={editingUser.email || ''} onChange={(e) => setEditingUser({...editingUser, email: e.target.value})} />
            </div>
            <div className="space-y-2">
              <Label>角色</Label>
              <Select 
                value={editingUser.role} 
                onValueChange={(v: any) => setEditingUser({...editingUser, role: v})}
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="admin">管理员</SelectItem>
                  <SelectItem value="manager">部门经理</SelectItem>
                  <SelectItem value="boss">总经理</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label>部门</Label>
              <Select 
                value={editingUser.departmentId || 'none'} 
                onValueChange={(v) => setEditingUser({...editingUser, departmentId: v === 'none' ? undefined : v})}
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="none">无</SelectItem>
                  {departments.map(dept => (
                    <SelectItem key={dept.id} value={dept.id}>{dept.name}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>
          <div className="flex justify-end gap-2">
            <Button variant="outline" onClick={() => setUserDialogOpen(false)}>取消</Button>
            <Button onClick={handleSaveUser}>保存</Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
