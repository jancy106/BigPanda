import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { AlertCircle, Mail, Lock, Sparkles } from 'lucide-react';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { login } from '@/services/dataService';
import type { User } from '@/types';

interface LoginFormProps {
  onLogin: (user: User) => void;
}

export function LoginForm({ onLogin }: LoginFormProps) {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [isLoading, setIsLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setIsLoading(true);

    // 模拟API调用延迟
    await new Promise(resolve => setTimeout(resolve, 500));

    const user = login(email, password);
    if (user) {
      onLogin(user);
    } else {
      setError('邮箱或密码错误');
    }
    setIsLoading(false);
  };

  // 快速登录选项
  const quickLogin = (email: string) => {
    setEmail(email);
    setPassword('password');
  };

  return (
    <div className="min-h-screen flex items-center justify-center relative overflow-hidden bg-gradient-to-br from-[#1d6a70] via-[#1d6a70] to-[#2c3e50]">
      {/* 背景装饰 */}
      <div className="absolute inset-0 overflow-hidden">
        <div className="absolute -top-40 -right-40 w-80 h-80 bg-[#b1d658]/20 rounded-full blur-3xl" />
        <div className="absolute -bottom-40 -left-40 w-80 h-80 bg-[#1d6a70]/30 rounded-full blur-3xl" />
      </div>

      {/* 渐变叠加 */}
      <div className="absolute inset-0 bg-gradient-to-br from-[#1d6a70]/80 via-transparent to-[#2c3e50]/80" />

      {/* 登录卡片 */}
      <Card className="w-full max-w-md relative z-10 backdrop-blur-xl bg-white/10 border-white/20 shadow-2xl animate-fade-in">
        <CardHeader className="space-y-1 text-center">
          <div className="flex justify-center mb-4">
            <div className="w-16 h-16 rounded-full bg-gradient-to-br from-[#b1d658] to-[#1d6a70] flex items-center justify-center shadow-lg animate-pulse">
              <Sparkles className="w-8 h-8 text-white" />
            </div>
          </div>
          <CardTitle className="text-2xl font-bold text-white">欢迎回来</CardTitle>
          <CardDescription className="text-white/70">
            登录以访问您的财务仪表板
          </CardDescription>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleSubmit} className="space-y-4">
            {error && (
              <Alert variant="destructive" className="bg-red-500/20 border-red-500/50">
                <AlertCircle className="h-4 w-4" />
                <AlertDescription>{error}</AlertDescription>
              </Alert>
            )}

            <div className="space-y-2">
              <Label htmlFor="email" className="text-white/90">邮箱</Label>
              <div className="relative">
                <Mail className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-white/50" />
                <Input
                  id="email"
                  type="email"
                  placeholder="请输入邮箱"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="pl-10 bg-white/10 border-white/20 text-white placeholder:text-white/50 focus:border-[#b1d658] focus:ring-[#b1d658]/20"
                  required
                />
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="password" className="text-white/90">密码</Label>
              <div className="relative">
                <Lock className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-white/50" />
                <Input
                  id="password"
                  type="password"
                  placeholder="请输入密码"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="pl-10 bg-white/10 border-white/20 text-white placeholder:text-white/50 focus:border-[#b1d658] focus:ring-[#b1d658]/20"
                  required
                />
              </div>
            </div>

            <Button
              type="submit"
              className="w-full bg-gradient-to-r from-[#b1d658] to-[#1d6a70] hover:from-[#c5e470] hover:to-[#2a8a91] text-white font-semibold py-2 transition-all duration-300 hover:shadow-lg hover:shadow-[#b1d658]/30"
              disabled={isLoading}
            >
              {isLoading ? (
                <div className="flex items-center gap-2">
                  <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                  登录中...
                </div>
              ) : (
                '登录'
              )}
            </Button>
          </form>

          {/* 快速登录选项 */}
          <div className="mt-6 pt-4 border-t border-white/10">
            <p className="text-xs text-white/50 text-center mb-3">快速登录（演示用）</p>
            <div className="flex flex-wrap gap-2 justify-center">
              {[
                { label: '管理员', email: 'admin@biopharma.com' },
                { label: '总经理', email: 'boss@biopharma.com' },
                { label: '研发经理', email: 'qiao@biopharma.com' }
              ].map((item) => (
                <button
                  key={item.email}
                  onClick={() => quickLogin(item.email)}
                  className="px-3 py-1 text-xs bg-white/10 hover:bg-white/20 text-white/70 hover:text-white rounded-full transition-all duration-200"
                >
                  {item.label}
                </button>
              ))}
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
