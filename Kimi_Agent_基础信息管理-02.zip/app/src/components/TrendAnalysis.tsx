import { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { 
  TrendingUp, 
  Calendar,
  Building2,
  FolderGit2,
  Download
} from 'lucide-react';
import { 
  LineChart, 
  Line, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer,
  Legend,
  AreaChart,
  Area,
  BarChart,
  Bar
} from 'recharts';
import { calculateBudgetExecution, getDepartments, getProjects } from '@/services/dataService';
import type { TrendData, User } from '@/types';
import { formatCurrency } from '@/lib/utils';
import { toast } from 'sonner';
import * as XLSX from 'xlsx';

interface TrendAnalysisProps {
  user: User;
}

export function TrendAnalysis({ user }: TrendAnalysisProps) {
  const [activeTab, setActiveTab] = useState('monthly');
  const [selectedYear, setSelectedYear] = useState(2026);
  const [filterDepartment, setFilterDepartment] = useState<string>('all');
  const [filterProject, setFilterProject] = useState<string>('all');
  const [departments, setDepartments] = useState<{id: string, name: string}[]>([]);
  const [projects, setProjects] = useState<{id: string, name: string}[]>([]);
  const [monthlyTrend, setMonthlyTrend] = useState<TrendData[]>([]);
  const [quarterlyTrend, setQuarterlyTrend] = useState<TrendData[]>([]);
  const [departmentTrend, setDepartmentTrend] = useState<any[]>([]);

  useEffect(() => {
    loadData();
  }, [selectedYear, filterDepartment, filterProject, user]);

  const loadData = () => {
    setDepartments(getDepartments());
    setProjects(getProjects());

    // 生成月度趋势数据
    const monthlyData: TrendData[] = [];
    for (let month = 1; month <= 12; month++) {
      let executions = calculateBudgetExecution(selectedYear, month);
      
      if (filterDepartment !== 'all') {
        executions = executions.filter(e => e.departmentId === filterDepartment);
      }
      if (filterProject !== 'all') {
        executions = executions.filter(e => e.projectId === filterProject);
      }
      if (user.role === 'manager' && user.departmentId) {
        executions = executions.filter(e => e.departmentId === user.departmentId);
      }

      const budget = executions.reduce((sum, e) => sum + e.monthlyBudget, 0);
      const actual = executions.reduce((sum, e) => sum + e.actualExpense, 0);
      
      monthlyData.push({
        period: `${month}月`,
        budget,
        actual,
        variance: actual - budget,
        executionRate: budget > 0 ? (actual / budget) * 100 : 0
      });
    }
    setMonthlyTrend(monthlyData);

    // 生成季度趋势数据
    const quarterlyData: TrendData[] = [];
    for (let q = 1; q <= 4; q++) {
      const startMonth = (q - 1) * 3 + 1;
      const endMonth = q * 3;
      let budget = 0;
      let actual = 0;
      
      for (let m = startMonth; m <= endMonth; m++) {
        let executions = calculateBudgetExecution(selectedYear, m);
        
        if (filterDepartment !== 'all') {
          executions = executions.filter(e => e.departmentId === filterDepartment);
        }
        if (filterProject !== 'all') {
          executions = executions.filter(e => e.projectId === filterProject);
        }
        if (user.role === 'manager' && user.departmentId) {
          executions = executions.filter(e => e.departmentId === user.departmentId);
        }

        budget += executions.reduce((sum, e) => sum + e.monthlyBudget, 0);
        actual += executions.reduce((sum, e) => sum + e.actualExpense, 0);
      }
      
      quarterlyData.push({
        period: `Q${q}`,
        budget,
        actual,
        variance: actual - budget,
        executionRate: budget > 0 ? (actual / budget) * 100 : 0
      });
    }
    setQuarterlyTrend(quarterlyData);

    // 生成部门趋势数据
    const deptData: any[] = [];
    const depts = getDepartments();
    depts.forEach(dept => {
      if (user.role === 'manager' && user.departmentId !== dept.id) return;
      
      const deptMonthly: number[] = [];
      for (let month = 1; month <= 12; month++) {
        const executions = calculateBudgetExecution(selectedYear, month)
          .filter(e => e.departmentId === dept.id);
        const actual = executions.reduce((sum, e) => sum + e.actualExpense, 0);
        deptMonthly.push(actual);
      }
      
      deptData.push({
        name: dept.name,
        data: deptMonthly,
        total: deptMonthly.reduce((sum, v) => sum + v, 0)
      });
    });
    setDepartmentTrend(deptData.slice(0, 5)); // 只显示前5个部门
  };

  const handleExport = () => {
    const data = monthlyTrend.map(t => ({
      '期间': t.period,
      '预算': t.budget,
      '实际': t.actual,
      '差异': t.variance,
      '执行率': `${t.executionRate.toFixed(2)}%`
    }));

    const ws = XLSX.utils.json_to_sheet(data);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, '趋势分析');
    XLSX.writeFile(wb, `趋势分析_${selectedYear}.xlsx`);
    toast.success('导出成功');
  };

  const executionRateData = monthlyTrend.map(t => ({
    period: t.period,
    rate: parseFloat(t.executionRate.toFixed(1))
  }));

  return (
    <div className="p-6 space-y-6 animate-in fade-in duration-500">
      {/* 页面标题 */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-[#2c3e50]">趋势分析</h1>
          <p className="text-sm text-gray-500 mt-1">按月度/季度追踪预算执行趋势</p>
        </div>
        <Button variant="outline" onClick={handleExport}>
          <Download className="h-4 w-4 mr-2" />
          导出数据
        </Button>
      </div>

      {/* 筛选栏 */}
      <div className="flex flex-wrap gap-4">
        <Select value={String(selectedYear)} onValueChange={(v) => setSelectedYear(Number(v))}>
          <SelectTrigger className="w-32">
            <Calendar className="h-4 w-4 mr-2" />
            <SelectValue placeholder="选择年份" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="2025">2025年</SelectItem>
            <SelectItem value="2026">2026年</SelectItem>
            <SelectItem value="2027">2027年</SelectItem>
          </SelectContent>
        </Select>
        <Select value={filterDepartment} onValueChange={setFilterDepartment}>
          <SelectTrigger className="w-40">
            <Building2 className="h-4 w-4 mr-2" />
            <SelectValue placeholder="筛选部门" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">全部部门</SelectItem>
            {departments.map(dept => (
              <SelectItem key={dept.id} value={dept.id}>{dept.name}</SelectItem>
            ))}
          </SelectContent>
        </Select>
        <Select value={filterProject} onValueChange={setFilterProject}>
          <SelectTrigger className="w-40">
            <FolderGit2 className="h-4 w-4 mr-2" />
            <SelectValue placeholder="筛选项目" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">全部项目</SelectItem>
            {projects.map(proj => (
              <SelectItem key={proj.id} value={proj.id}>{proj.name}</SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      {/* 图表标签页 */}
      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList className="grid w-full max-w-md grid-cols-3">
          <TabsTrigger value="monthly">月度趋势</TabsTrigger>
          <TabsTrigger value="quarterly">季度趋势</TabsTrigger>
          <TabsTrigger value="department">部门对比</TabsTrigger>
        </TabsList>

        <TabsContent value="monthly" className="space-y-6">
          {/* 月度趋势图 */}
          <Card>
            <CardHeader>
              <CardTitle className="text-lg flex items-center gap-2">
                <TrendingUp className="h-5 w-5 text-[#1d6a70]" />
                月度预算执行趋势
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="h-80">
                <ResponsiveContainer width="100%" height="100%">
                  <AreaChart data={monthlyTrend}>
                    <defs>
                      <linearGradient id="colorBudget" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="5%" stopColor="#1d6a70" stopOpacity={0.3}/>
                        <stop offset="95%" stopColor="#1d6a70" stopOpacity={0}/>
                      </linearGradient>
                      <linearGradient id="colorActual" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="5%" stopColor="#b1d658" stopOpacity={0.3}/>
                        <stop offset="95%" stopColor="#b1d658" stopOpacity={0}/>
                      </linearGradient>
                    </defs>
                    <CartesianGrid strokeDasharray="3 3" stroke="#e0e0e0" />
                    <XAxis dataKey="period" />
                    <YAxis tickFormatter={(value) => formatCurrency(value, true)} />
                    <Tooltip formatter={(value: number) => formatCurrency(value)} />
                    <Legend />
                    <Area type="monotone" dataKey="budget" name="预算" stroke="#1d6a70" fillOpacity={1} fill="url(#colorBudget)" />
                    <Area type="monotone" dataKey="actual" name="实际" stroke="#b1d658" fillOpacity={1} fill="url(#colorActual)" />
                  </AreaChart>
                </ResponsiveContainer>
              </div>
            </CardContent>
          </Card>

          {/* 执行率趋势 */}
          <Card>
            <CardHeader>
              <CardTitle className="text-lg flex items-center gap-2">
                <TrendingUp className="h-5 w-5 text-[#1d6a70]" />
                月度执行率趋势
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="h-64">
                <ResponsiveContainer width="100%" height="100%">
                  <LineChart data={executionRateData}>
                    <CartesianGrid strokeDasharray="3 3" stroke="#e0e0e0" />
                    <XAxis dataKey="period" />
                    <YAxis domain={[0, 150]} tickFormatter={(value) => `${value}%`} />
                    <Tooltip formatter={(value: number) => `${value}%`} />
                    <Line 
                      type="monotone" 
                      dataKey="rate" 
                      name="执行率" 
                      stroke="#f4a261" 
                      strokeWidth={3}
                      dot={{ fill: '#f4a261', strokeWidth: 2 }}
                    />
                    {/* 参考线 */}
                    <line x1="0" y1="100" x2="100%" y2="100" stroke="#e76f51" strokeDasharray="5 5" />
                  </LineChart>
                </ResponsiveContainer>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="quarterly" className="space-y-6">
          {/* 季度趋势图 */}
          <Card>
            <CardHeader>
              <CardTitle className="text-lg flex items-center gap-2">
                <TrendingUp className="h-5 w-5 text-[#1d6a70]" />
                季度预算执行趋势
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="h-80">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={quarterlyTrend}>
                    <CartesianGrid strokeDasharray="3 3" stroke="#e0e0e0" />
                    <XAxis dataKey="period" />
                    <YAxis tickFormatter={(value) => formatCurrency(value, true)} />
                    <Tooltip formatter={(value: number) => formatCurrency(value)} />
                    <Legend />
                    <Bar dataKey="budget" name="预算" fill="#1d6a70" />
                    <Bar dataKey="actual" name="实际" fill="#b1d658" />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </CardContent>
          </Card>

          {/* 季度统计卡片 */}
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            {quarterlyTrend.map((q, index) => (
              <Card key={index} className="hover:shadow-lg transition-shadow">
                <CardContent className="p-4">
                  <p className="text-sm text-gray-500">{q.period}</p>
                  <p className="text-lg font-bold text-[#2c3e50]">{formatCurrency(q.actual, true)}</p>
                  <div className="flex items-center gap-2 mt-2">
                    <Badge variant={q.executionRate > 100 ? 'destructive' : q.executionRate > 80 ? 'default' : 'secondary'}>
                      {q.executionRate.toFixed(1)}%
                    </Badge>
                    <span className="text-xs text-gray-400">执行率</span>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="department" className="space-y-6">
          {/* 部门对比图 */}
          <Card>
            <CardHeader>
              <CardTitle className="text-lg flex items-center gap-2">
                <Building2 className="h-5 w-5 text-[#1d6a70]" />
                部门支出对比
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="h-80">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={departmentTrend.map(d => ({
                    name: d.name,
                    total: d.total
                  }))} layout="vertical">
                    <CartesianGrid strokeDasharray="3 3" stroke="#e0e0e0" />
                    <XAxis type="number" tickFormatter={(value) => formatCurrency(value, true)} />
                    <YAxis type="category" dataKey="name" width={100} />
                    <Tooltip formatter={(value: number) => formatCurrency(value)} />
                    <Bar dataKey="total" name="年度支出" fill="#1d6a70" />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </CardContent>
          </Card>

          {/* 部门统计表格 */}
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">部门支出排名</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {departmentTrend
                  .sort((a, b) => b.total - a.total)
                  .map((dept, index) => (
                    <div key={dept.name} className="flex items-center gap-4">
                      <span className="w-8 h-8 rounded-full bg-gradient-to-br from-[#1d6a70] to-[#b1d658] flex items-center justify-center text-white text-sm font-bold">
                        {index + 1}
                      </span>
                      <div className="flex-1">
                        <div className="flex items-center justify-between mb-1">
                          <span className="font-medium">{dept.name}</span>
                          <span className="text-sm font-bold">{formatCurrency(dept.total)}</span>
                        </div>
                        <div className="h-2 bg-gray-100 rounded-full overflow-hidden">
                          <div 
                            className="h-full bg-gradient-to-r from-[#1d6a70] to-[#b1d658] rounded-full transition-all duration-1000"
                            style={{ 
                              width: `${(dept.total / (departmentTrend[0]?.total || 1)) * 100}%` 
                            }}
                          />
                        </div>
                      </div>
                    </div>
                  ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
