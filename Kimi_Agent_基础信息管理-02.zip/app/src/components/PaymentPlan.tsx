import { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Badge } from '@/components/ui/badge';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { 
  Plus, 
  Search, 
  Edit2, 
  Trash2, 
  Send, 
  CheckCircle2, 
  XCircle, 
  Clock,
  AlertTriangle,
  CreditCard,
  Calendar
} from 'lucide-react';
import { 
  getPaymentPlans, 
  getDepartments, 
  getSubjects, 
  getProjects,
  getMonthlyBudgets,
  savePaymentPlan,
  deletePaymentPlan,
  getSystemConfig
} from '@/services/dataService';
import type { PaymentPlan, Department, AccountSubject, Project, User } from '@/types';
import { formatCurrency } from '@/lib/utils';
import { toast } from 'sonner';

interface PaymentPlanProps {
  user: User;
}

export function PaymentPlanModule({ user }: PaymentPlanProps) {
  const [plans, setPlans] = useState<PaymentPlan[]>([]);
  const [departments, setDepartments] = useState<Department[]>([]);
  const [subjects, setSubjects] = useState<AccountSubject[]>([]);
  const [projects, setProjects] = useState<Project[]>([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedYear, setSelectedYear] = useState(2026);
  const [selectedMonth, setSelectedMonth] = useState(4);
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [editingPlan, setEditingPlan] = useState<Partial<PaymentPlan> | null>(null);
  const [comparisonData, setComparisonData] = useState<Record<string, { budget: number; plan: number; variance: number }>>({});

  useEffect(() => {
    loadData();
  }, [selectedYear, selectedMonth, user]);

  const loadData = () => {
    setDepartments(getDepartments());
    setSubjects(getSubjects());
    setProjects(getProjects());
    
    // 根据用户角色加载数据
    const departmentId = user.role === 'manager' ? user.departmentId : undefined;
    const planData = getPaymentPlans(selectedYear, selectedMonth, departmentId);
    setPlans(planData);

    // 计算对比数据
    const monthlyBudgets = getMonthlyBudgets(selectedYear, selectedMonth);
    const comparison: Record<string, { budget: number; plan: number; variance: number }> = {};
    
    planData.forEach(plan => {
      const key = `${plan.departmentId}_${plan.subjectId}`;
      const budget = monthlyBudgets.find(
        mb => mb.departmentId === plan.departmentId && mb.subjectId === plan.subjectId
      );
      const existing = comparison[key] || { budget: budget?.amount || 0, plan: 0, variance: 0 };
      existing.plan += plan.amount;
      existing.variance = existing.plan - existing.budget;
      comparison[key] = existing;
    });
    
    setComparisonData(comparison);
  };

  const handleSave = () => {
    if (!editingPlan?.departmentId || !editingPlan?.subjectId || !editingPlan?.amount) {
      toast.error('请填写完整信息');
      return;
    }

    const plan: PaymentPlan = {
      id: editingPlan.id || `pp_${Date.now()}`,
      year: selectedYear,
      month: selectedMonth,
      departmentId: editingPlan.departmentId,
      subjectId: editingPlan.subjectId,
      projectId: editingPlan.projectId,
      amount: Number(editingPlan.amount),
      description: editingPlan.description || '',
      vendor: editingPlan.vendor,
      status: editingPlan.status || 'draft',
      submitterId: user.id,
      submittedAt: editingPlan.submittedAt || new Date().toISOString()
    };

    savePaymentPlan(plan);
    toast.success('保存成功');
    setIsDialogOpen(false);
    setEditingPlan(null);
    loadData();
  };

  const handleSubmit = (planId: string) => {
    const plan = plans.find(p => p.id === planId);
    if (plan) {
      plan.status = 'submitted';
      plan.submittedAt = new Date().toISOString();
      savePaymentPlan(plan);
      toast.success('提交成功');
      loadData();
    }
  };

  const handleApprove = (planId: string, approved: boolean) => {
    const plan = plans.find(p => p.id === planId);
    if (plan) {
      plan.status = approved ? 'approved' : 'rejected';
      plan.approvedAt = new Date().toISOString();
      plan.approverId = user.id;
      savePaymentPlan(plan);
      toast.success(approved ? '审批通过' : '已驳回');
      loadData();
    }
  };

  const handleDelete = (id: string) => {
    if (confirm('确定要删除这条付款计划吗？')) {
      deletePaymentPlan(id);
      toast.success('删除成功');
      loadData();
    }
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'draft':
        return <Badge variant="secondary" className="flex items-center gap-1"><Clock className="h-3 w-3" /> 草稿</Badge>;
      case 'submitted':
        return <Badge variant="default" className="bg-blue-500 flex items-center gap-1"><Send className="h-3 w-3" /> 已提交</Badge>;
      case 'approved':
        return <Badge variant="default" className="bg-green-500 flex items-center gap-1"><CheckCircle2 className="h-3 w-3" /> 已批准</Badge>;
      case 'rejected':
        return <Badge variant="destructive" className="flex items-center gap-1"><XCircle className="h-3 w-3" /> 已驳回</Badge>;
      default:
        return null;
    }
  };

  const filteredPlans = plans.filter(plan => {
    const dept = departments.find(d => d.id === plan.departmentId);
    const subject = subjects.find(s => s.id === plan.subjectId);
    return (
      dept?.name.includes(searchTerm) ||
      subject?.name.includes(searchTerm) ||
      plan.description.includes(searchTerm)
    );
  });

  const totalPlanAmount = filteredPlans.reduce((sum, p) => sum + p.amount, 0);
  const config = getSystemConfig();
  const deadline = config.paymentPlanDeadline;
  const today = new Date().getDate();
  const daysToDeadline = deadline - today;

  return (
    <div className="p-6 space-y-6 animate-in fade-in duration-500">
      {/* 页面标题 */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-[#2c3e50]">付款计划</h1>
          <p className="text-sm text-gray-500 mt-1">部门提交下月付款计划与预算对比分析</p>
        </div>
        {user.role !== 'boss' && (
          <Button 
            onClick={() => {
              setEditingPlan({});
              setIsDialogOpen(true);
            }}
            className="bg-gradient-to-r from-[#1d6a70] to-[#2a9d8f] hover:from-[#2a8a91] hover:to-[#1d6a70]"
          >
            <Plus className="h-4 w-4 mr-2" />
            新增计划
          </Button>
        )}
      </div>

      {/* 截止提醒 */}
      {daysToDeadline > 0 && daysToDeadline <= 5 && (
        <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-4 flex items-center gap-3">
          <AlertTriangle className="h-5 w-5 text-yellow-600" />
          <div>
            <p className="font-medium text-yellow-800">付款计划提交截止提醒</p>
            <p className="text-sm text-yellow-600">距离{selectedMonth}月付款计划提交截止还有 {daysToDeadline} 天（截止日：每月{deadline}日）</p>
          </div>
        </div>
      )}

      {/* 统计卡片 */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card className="bg-gradient-to-br from-[#1d6a70] to-[#2a9d8f] text-white">
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <CreditCard className="h-8 w-8 opacity-80" />
              <div>
                <p className="text-sm opacity-80">计划总额</p>
                <p className="text-2xl font-bold">{formatCurrency(totalPlanAmount)}</p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card className="bg-gradient-to-br from-[#b1d658] to-[#7cb342] text-white">
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <Calendar className="h-8 w-8 opacity-80" />
              <div>
                <p className="text-sm opacity-80">计划条目</p>
                <p className="text-2xl font-bold">{filteredPlans.length}</p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card className="bg-gradient-to-br from-[#f4a261] to-[#e76f51] text-white">
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <Clock className="h-8 w-8 opacity-80" />
              <div>
                <p className="text-sm opacity-80">待提交</p>
                <p className="text-2xl font-bold">{filteredPlans.filter(p => p.status === 'draft').length}</p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card className="bg-gradient-to-br from-green-500 to-green-600 text-white">
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <CheckCircle2 className="h-8 w-8 opacity-80" />
              <div>
                <p className="text-sm opacity-80">已批准</p>
                <p className="text-2xl font-bold">{filteredPlans.filter(p => p.status === 'approved').length}</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* 筛选栏 */}
      <div className="flex gap-4">
        <div className="relative flex-1 max-w-sm">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-gray-400" />
          <Input
            placeholder="搜索部门、科目或描述..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="pl-10"
          />
        </div>
        <Select value={String(selectedYear)} onValueChange={(v) => setSelectedYear(Number(v))}>
          <SelectTrigger className="w-32">
            <SelectValue placeholder="选择年份" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="2025">2025年</SelectItem>
            <SelectItem value="2026">2026年</SelectItem>
            <SelectItem value="2027">2027年</SelectItem>
          </SelectContent>
        </Select>
        <Select value={String(selectedMonth)} onValueChange={(v) => setSelectedMonth(Number(v))}>
          <SelectTrigger className="w-32">
            <SelectValue placeholder="选择月份" />
          </SelectTrigger>
          <SelectContent>
            {Array.from({ length: 12 }, (_, i) => (
              <SelectItem key={i + 1} value={String(i + 1)}>{i + 1}月</SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      {/* 付款计划表格 */}
      <Card>
        <CardHeader>
          <CardTitle className="text-lg flex items-center gap-2">
            <CreditCard className="h-5 w-5 text-[#1d6a70]" />
            付款计划列表
          </CardTitle>
        </CardHeader>
        <CardContent className="p-0">
          <ScrollArea className="h-[500px]">
            <Table>
              <TableHeader className="sticky top-0 bg-white z-10">
                <TableRow>
                  <TableHead>部门</TableHead>
                  <TableHead>科目</TableHead>
                  <TableHead>描述</TableHead>
                  <TableHead className="text-right">金额</TableHead>
                  <TableHead>状态</TableHead>
                  <TableHead className="text-right">操作</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredPlans.map((plan) => {
                  const dept = departments.find(d => d.id === plan.departmentId);
                  const subject = subjects.find(s => s.id === plan.subjectId);
                  const key = `${plan.departmentId}_${plan.subjectId}`;
                  const comparison = comparisonData[key];
                  const hasVariance = comparison && comparison.variance > 0;
                  
                  return (
                    <TableRow key={plan.id} className={hasVariance ? 'bg-red-50/50' : ''}>
                      <TableCell>
                        <Badge variant="outline">{dept?.name}</Badge>
                      </TableCell>
                      <TableCell>{subject?.name}</TableCell>
                      <TableCell>
                        <span className="text-sm text-gray-600">{plan.description}</span>
                        {plan.vendor && (
                          <span className="text-xs text-gray-400 block">供应商: {plan.vendor}</span>
                        )}
                      </TableCell>
                      <TableCell className="text-right">
                        <div className="font-medium">{formatCurrency(plan.amount)}</div>
                        {comparison && (
                          <div className={`text-xs ${comparison.variance > 0 ? 'text-red-500' : 'text-green-500'}`}>
                            预算: {formatCurrency(comparison.budget, true)}
                            {comparison.variance > 0 && ` (+${formatCurrency(comparison.variance, true)})`}
                          </div>
                        )}
                      </TableCell>
                      <TableCell>{getStatusBadge(plan.status)}</TableCell>
                      <TableCell className="text-right">
                        <div className="flex items-center justify-end gap-1">
                          {plan.status === 'draft' && user.role === 'manager' && (
                            <>
                              <Button
                                variant="ghost"
                                size="icon"
                                onClick={() => {
                                  setEditingPlan(plan);
                                  setIsDialogOpen(true);
                                }}
                              >
                                <Edit2 className="h-4 w-4" />
                              </Button>
                              <Button
                                variant="ghost"
                                size="icon"
                                onClick={() => handleSubmit(plan.id)}
                                className="text-blue-500"
                              >
                                <Send className="h-4 w-4" />
                              </Button>
                              <Button
                                variant="ghost"
                                size="icon"
                                onClick={() => handleDelete(plan.id)}
                              >
                                <Trash2 className="h-4 w-4 text-red-500" />
                              </Button>
                            </>
                          )}
                          {plan.status === 'submitted' && user.role === 'admin' && (
                            <>
                              <Button
                                variant="ghost"
                                size="sm"
                                onClick={() => handleApprove(plan.id, true)}
                                className="text-green-600"
                              >
                                批准
                              </Button>
                              <Button
                                variant="ghost"
                                size="sm"
                                onClick={() => handleApprove(plan.id, false)}
                                className="text-red-600"
                              >
                                驳回
                              </Button>
                            </>
                          )}
                        </div>
                      </TableCell>
                    </TableRow>
                  );
                })}
              </TableBody>
            </Table>
          </ScrollArea>
        </CardContent>
      </Card>

      {/* 编辑对话框 */}
      <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
        <DialogContent className="max-w-lg">
          <DialogHeader>
            <DialogTitle>{editingPlan?.id ? '编辑付款计划' : '新增付款计划'}</DialogTitle>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label>年份</Label>
                <Input value={selectedYear} disabled />
              </div>
              <div className="space-y-2">
                <Label>月份</Label>
                <Input value={selectedMonth} disabled />
              </div>
            </div>
            <div className="space-y-2">
              <Label>部门</Label>
              <Select 
                value={editingPlan?.departmentId} 
                onValueChange={(v) => setEditingPlan({...editingPlan, departmentId: v})}
              >
                <SelectTrigger>
                  <SelectValue placeholder="选择部门" />
                </SelectTrigger>
                <SelectContent>
                  {departments
                    .filter(d => user.role === 'admin' || d.id === user.departmentId)
                    .map(dept => (
                      <SelectItem key={dept.id} value={dept.id}>{dept.name}</SelectItem>
                    ))}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label>预算科目</Label>
              <Select 
                value={editingPlan?.subjectId} 
                onValueChange={(v) => setEditingPlan({...editingPlan, subjectId: v})}
              >
                <SelectTrigger>
                  <SelectValue placeholder="选择科目" />
                </SelectTrigger>
                <SelectContent>
                  {subjects.map(subject => (
                    <SelectItem key={subject.id} value={subject.id}>{subject.name}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label>项目（可选）</Label>
              <Select 
                value={editingPlan?.projectId || 'none'} 
                onValueChange={(v) => setEditingPlan({...editingPlan, projectId: v === 'none' ? undefined : v})}
              >
                <SelectTrigger>
                  <SelectValue placeholder="选择项目" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="none">无项目</SelectItem>
                  {projects.map(project => (
                    <SelectItem key={project.id} value={project.id}>{project.name}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label>付款金额</Label>
              <Input
                type="number"
                placeholder="请输入付款金额"
                value={editingPlan?.amount || ''}
                onChange={(e) => setEditingPlan({...editingPlan, amount: Number(e.target.value)})}
              />
            </div>
            <div className="space-y-2">
              <Label>付款说明</Label>
              <Input
                placeholder="请输入付款说明"
                value={editingPlan?.description || ''}
                onChange={(e) => setEditingPlan({...editingPlan, description: e.target.value})}
              />
            </div>
            <div className="space-y-2">
              <Label>供应商（可选）</Label>
              <Input
                placeholder="请输入供应商名称"
                value={editingPlan?.vendor || ''}
                onChange={(e) => setEditingPlan({...editingPlan, vendor: e.target.value})}
              />
            </div>
          </div>
          <div className="flex justify-end gap-2">
            <Button variant="outline" onClick={() => setIsDialogOpen(false)}>取消</Button>
            <Button onClick={handleSave} className="bg-[#1d6a70] hover:bg-[#2a8a91]">保存</Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
