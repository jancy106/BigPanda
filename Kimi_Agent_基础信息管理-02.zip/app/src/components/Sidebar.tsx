import { useState } from 'react';
import { cn } from '@/lib/utils';
import { Button } from '@/components/ui/button';
import { ScrollArea } from '@/components/ui/scroll-area';
import { 
  LayoutDashboard, 
  Wallet, 
  CreditCard, 
  BarChart3, 
  TrendingUp, 
  Brain,
  FileSpreadsheet,
  FolderGit2,
  Settings,
  ChevronLeft,
  ChevronRight,
  LogOut
} from 'lucide-react';
import type { User } from '@/types';
import { logout } from '@/services/dataService';

interface SidebarProps {
  user: User;
  activeModule: string;
  onModuleChange: (module: string) => void;
  onLogout: () => void;
}

interface NavItem {
  id: string;
  label: string;
  icon: React.ElementType;
  allowedRoles: string[];
  badge?: number;
}

const navItems: NavItem[] = [
  { id: 'dashboard', label: '仪表盘', icon: LayoutDashboard, allowedRoles: ['admin', 'manager', 'boss'] },
  { id: 'budget', label: '预算管理', icon: Wallet, allowedRoles: ['admin', 'boss'] },
  { id: 'payment-plan', label: '付款计划', icon: CreditCard, allowedRoles: ['admin', 'manager', 'boss'] },
  { id: 'expense', label: '支出管理', icon: FileSpreadsheet, allowedRoles: ['admin', 'manager', 'boss'] },
  { id: 'variance', label: '差异分析', icon: BarChart3, allowedRoles: ['admin', 'manager', 'boss'] },
  { id: 'trend', label: '趋势分析', icon: TrendingUp, allowedRoles: ['admin', 'manager', 'boss'] },
  { id: 'ai-insights', label: 'AI洞察', icon: Brain, allowedRoles: ['admin', 'manager', 'boss'] },
  { id: 'project', label: '项目分析', icon: FolderGit2, allowedRoles: ['admin', 'manager', 'boss'] },
  { id: 'settings', label: '系统配置', icon: Settings, allowedRoles: ['admin'] },
];

export function Sidebar({ user, activeModule, onModuleChange, onLogout }: SidebarProps) {
  const [collapsed, setCollapsed] = useState(false);

  const filteredNavItems = navItems.filter(item => 
    item.allowedRoles.includes(user.role)
  );

  const handleLogout = () => {
    logout();
    onLogout();
  };

  return (
    <div 
      className={cn(
        "h-screen bg-gradient-to-b from-[#1d6a70] to-[#2c3e50] text-white transition-all duration-500 flex flex-col",
        collapsed ? "w-20" : "w-64"
      )}
    >
      {/* Logo区域 */}
      <div className="p-4 flex items-center justify-between border-b border-white/10">
        {!collapsed && (
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-lg bg-gradient-to-br from-[#b1d658] to-[#1d6a70] flex items-center justify-center shadow-lg">
              <span className="text-lg font-bold text-white">B</span>
            </div>
            <div className="overflow-hidden">
              <h1 className="font-bold text-sm whitespace-nowrap">BioPharma</h1>
              <p className="text-xs text-white/60 whitespace-nowrap">财务管理系统</p>
            </div>
          </div>
        )}
        {collapsed && (
          <div className="w-10 h-10 rounded-lg bg-gradient-to-br from-[#b1d658] to-[#1d6a70] flex items-center justify-center shadow-lg mx-auto">
            <span className="text-lg font-bold text-white">B</span>
          </div>
        )}
        {!collapsed && (
          <Button
            variant="ghost"
            size="icon"
            onClick={() => setCollapsed(true)}
            className="text-white/60 hover:text-white hover:bg-white/10"
          >
            <ChevronLeft className="h-4 w-4" />
          </Button>
        )}
        {collapsed && (
          <Button
            variant="ghost"
            size="icon"
            onClick={() => setCollapsed(false)}
            className="text-white/60 hover:text-white hover:bg-white/10 absolute -right-3 top-4 bg-[#1d6a70] rounded-full w-6 h-6"
          >
            <ChevronRight className="h-3 w-3" />
          </Button>
        )}
      </div>

      {/* 导航菜单 */}
      <ScrollArea className="flex-1 py-4">
        <nav className="px-2 space-y-1">
          {filteredNavItems.map((item) => {
            const Icon = item.icon;
            const isActive = activeModule === item.id;
            
            return (
              <button
                key={item.id}
                onClick={() => onModuleChange(item.id)}
                className={cn(
                  "w-full flex items-center gap-3 px-3 py-3 rounded-lg transition-all duration-300 group relative",
                  isActive 
                    ? "bg-white/20 text-white shadow-lg" 
                    : "text-white/70 hover:bg-white/10 hover:text-white"
                )}
              >
                <Icon className={cn(
                  "h-5 w-5 transition-transform duration-300",
                  isActive && "scale-110"
                )} />
                {!collapsed && (
                  <span className="text-sm font-medium whitespace-nowrap">{item.label}</span>
                )}
                {!collapsed && item.badge && (
                  <span className="ml-auto bg-[#f4a261] text-white text-xs px-2 py-0.5 rounded-full">
                    {item.badge}
                  </span>
                )}
                {collapsed && item.badge && (
                  <span className="absolute -top-1 -right-1 bg-[#f4a261] text-white text-xs w-4 h-4 flex items-center justify-center rounded-full">
                    {item.badge}
                  </span>
                )}
                
                {/* 悬停提示 */}
                {collapsed && (
                  <div className="absolute left-full ml-2 px-2 py-1 bg-[#2c3e50] text-white text-xs rounded opacity-0 group-hover:opacity-100 transition-opacity whitespace-nowrap z-50">
                    {item.label}
                  </div>
                )}
              </button>
            );
          })}
        </nav>
      </ScrollArea>

      {/* 用户信息 */}
      <div className="p-4 border-t border-white/10">
        {!collapsed ? (
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-full bg-gradient-to-br from-[#b1d658] to-[#f4a261] flex items-center justify-center">
              <span className="text-sm font-bold text-white">
                {user.name.charAt(0)}
              </span>
            </div>
            <div className="flex-1 min-w-0">
              <p className="text-sm font-medium truncate">{user.name}</p>
              <p className="text-xs text-white/60">
                {user.role === 'admin' ? '管理员' : user.role === 'boss' ? '总经理' : '部门经理'}
              </p>
            </div>
            <Button
              variant="ghost"
              size="icon"
              onClick={handleLogout}
              className="text-white/60 hover:text-white hover:bg-white/10"
            >
              <LogOut className="h-4 w-4" />
            </Button>
          </div>
        ) : (
          <div className="flex flex-col items-center gap-2">
            <div className="w-10 h-10 rounded-full bg-gradient-to-br from-[#b1d658] to-[#f4a261] flex items-center justify-center">
              <span className="text-sm font-bold text-white">
                {user.name.charAt(0)}
              </span>
            </div>
            <Button
              variant="ghost"
              size="icon"
              onClick={handleLogout}
              className="text-white/60 hover:text-white hover:bg-white/10"
            >
              <LogOut className="h-4 w-4" />
            </Button>
          </div>
        )}
      </div>
    </div>
  );
}
